#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include "debug.h"
#include "options.h"
#include "definitions.h"

extern options_t options;

void _debug(unsigned int fatal, unsigned nl, char *format, va_list ap)
{
    char head[] = "musa: ";
    char cfatal[] = "** FATAL ";

    if (fatal)
	fprintf(stderr, cfatal);
    if (nl)
	fprintf(stderr, head);

    vfprintf(stderr, format, ap);

    if (nl)
	fprintf(stderr, "\n");

}

void debug(int level, char *format, va_list ap)
{
    if (level <= DEBUG_LEVEL)
	_debug(0, 1, format, ap);
}

void debug_l(int level, char *format, va_list ap)
{

    if (level <= DEBUG_LEVEL)
	_debug(0, 0, format, ap);
}

void debug_nl(int level)
{
    if (level <= DEBUG_LEVEL)
	fprintf(stderr, "\n");
}

void error(char *format, ...)
{
    va_list ap;

    va_start(ap, format);
    _debug(1, 1, format, ap);
    va_end(ap);
    exit(-1);
}

void warn(char *format, ...)
{
    va_list ap;

    va_start(ap, format);
    debug(1, format, ap);
    va_end(ap);
}

void message(char *format, ...)
{
    va_list ap;

    va_start(ap, format);
    debug(1, format, ap);
    va_end(ap);
}

void message_l(char *format, ...)
{
    va_list ap;
    va_start(ap, format);
    debug_l(1, format, ap);
    va_end(ap);
}

void say(char *format, ...)
{
    va_list ap;
    va_start(ap, format);
    debug_l(1, format, ap);
    va_end(ap);
}

void say_nl()
{
    debug_nl(1);
}
