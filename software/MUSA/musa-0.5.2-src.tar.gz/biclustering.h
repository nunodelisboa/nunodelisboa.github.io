#ifndef BICLUSTERING_H
#define BICLUSTERING_H

#include "slist.h"
#include "blist.h"
#include "matrix.h"
#include "mrlist.h"

slist_t *generate_seeds(matrix_t *, ushort);
blist_t *extract_biclusters(matrix_t *, slist_t *);
bool_t check_bicluster(bicluster_t *, blist_t **);
void destroy_seeds(slist_t *);
void dump_biclusters(blist_t *);
mrlist_t *generate_mrlist(blist_t *);









#endif
