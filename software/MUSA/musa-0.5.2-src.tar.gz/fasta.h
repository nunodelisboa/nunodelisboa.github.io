#include "sequences.h"

dataset_t *parse_fasta(FILE *);
