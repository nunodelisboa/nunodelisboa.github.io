#include <stdlib.h>
#include <stdio.h>
#include "list.h"
#include "util.h"


/** 	Creates a generic list
*	@param f a generic comparison function
*	@param e a generic test for equality
*	@param i a generic function to return the id of an object
*
*	@returns the generic list
*/
list_t *creat_list(int (*f) (void *, void *), int (*e) (void *, void *),
		   unsigned int (*i) (void *))
{
    list_t *list = NULL;
    list = (list_t *) safe_malloc(sizeof(list_t));
    list->nelems = 0;
    list->first = NULL;
    list->last = NULL;
    list->compare = f;
    list->equal = e;
    list->id = i;

    return list;
}

/**	Creates a generic iterator
*	@param n the initial node of iteration
*	@return an iterator
*/
iterator_t *creat_iterator(list_node_t * n)
{

    iterator_t *i = NULL;
    i = (iterator_t *) safe_malloc(sizeof(iterator_t));
    i->iterator = n;

    return i;
}

/**	Tests if there is a next element to iterate to
*	@param i iterator
*	@returns true if the is a next element and false otherwise
*/
int iterator_has_next(iterator_t * i)
{
    return (i->iterator != NULL);
}

/**     Tests if there is a previous element to iterate to
*       @param i iterator
*       @returns true if the is a previous element and false otherwise
*/

int iterator_has_previous(iterator_t * i)
{
    return (i->iterator != NULL);
}

/**	Iterates to the next element
*	@param i iterate
*	@returns the element
*/
void *iterator_next(iterator_t * i)
{
    void *e = NULL;
    e = i->iterator->elem;
    i->iterator = i->iterator->next;
    return e;
}

/**     Iterates to the previous element
*       @param i iterate
*       @returns the element
*/
void *iterator_previous(iterator_t * i)
{
    void *e = NULL;
    e = i->iterator->elem;
    i->iterator = i->iterator->previous;
    return e;
}

/**	Destroys an iterator
*	@param i iterator
*/
void destroy_iterator(iterator_t * i)
{
    safe_free(i);
}

/**	Destroys a list
*	@param l list
*/
void list_destroy(list_t * l)
{
    list_node_t *node = NULL;
    if (l == NULL)
	return;
    while (l->first != NULL) {
	node = l->first;
	l->first = node->next;
	l->nelems--;
	safe_free(node);
    }
    safe_free(l);
}

/**	Creates a list node pointing to a given element
*	@param e the element
*	@returns a list node pointing to e
*/
list_node_t *creat_list_node(void *e)
{

    list_node_t *node = NULL;
    node = (list_node_t *) safe_malloc(sizeof(list_node_t));

    node->elem = e;
    node->next = NULL;
    node->previous = NULL;
    return node;
}

/** 	Default addition strategy 
*	@param l list
*	@param e element
*	@returns list with added element
*/
list_t *list_add_elem(list_t * l, void *e)
{
    return list_add_elem_t(l, e);
}

/** 	Adds element to ordered list, begins search by the head 
*	@see list_add_elem
*/
list_t *list_add_elem_h(list_t * list, void *e)
{

    list_node_t *node = NULL;
    list_node_t *np = NULL;
    list_node_t *pp = NULL;


    /* Single Element */

    if (list->nelems == 0) {
	node = creat_list_node(e);
	list->first = node;
	list->last = node;
	list->nelems++;
	return list;
    }

    /* Non-empty list */

    np = list->first;
    while (np != NULL
	   && (((int (*)(void *, void *)) (list->compare)) (np->elem, e) <
	       0)) {
	pp = np;
	np = np->next;
    }

    if (np != NULL) {

	/* we shall not have the same exact elem twice */
	if (((int (*)(void *, void *)) (list->equal)) (np->elem, e))
	    return list;


	node = creat_list_node(e);

	if (np == list->first) {
	    list->first = node;
	} else {
	    node->previous = pp;
	    pp->next = node;
	}
	node->next = np;
	np->previous = node;

    } else if (np == NULL) {
	node = creat_list_node(e);
	pp->next = node;
	node->previous = pp;
	list->last = node;

    }

    list->nelems++;

    return list;

}


/**  	Adds element to ordered list, begins search by the tail.
*	@see list_add_elem
*/
list_t *list_add_elem_t(list_t * list, void *e)
{

    list_node_t *node = NULL;
    list_node_t *np = NULL;
    list_node_t *pp = NULL;


    /* Single Element */

    if (list->nelems == 0) {
	node = creat_list_node(e);
	list->first = node;
	list->last = node;
	list->nelems++;
	return list;
    }

    /* Non-empty list */

    np = list->last;
    while (np != NULL
	   && (((int (*)(void *, void *)) (list->compare)) (np->elem, e) >
	       0)) {
	pp = np;
	np = np->previous;
    }

    if (np != NULL) {

	/* we shall not have the same exact elem twice */
	if (((int (*)(void *, void *)) (list->equal)) (np->elem, e))
	    return list;


	node = creat_list_node(e);

	if (np == list->last) {
	    list->last = node;
	} else {
	    node->next = pp;
	    pp->previous = node;
	}
	node->previous = np;
	np->next = node;

    } else if (np == NULL) {
	node = creat_list_node(e);
	pp->previous = node;
	node->next = pp;
	list->first = node;

    }

    list->nelems++;

    return list;

}

/**	Removes an element from a list by id
*	@param list list
*	@param id the id
*	@returns the list without the element identified by id (if any)
*/
list_t *list_remove_elem_id(list_t * list, unsigned int id)
{
    list_node_t *node = NULL;

    if (list == NULL)
	return list;

    node = list->first;
    while (node != NULL
	   && (((unsigned int (*)(void *)) (list->id)) (node->elem) != id))
	node = node->next;

    if (node == NULL)
	return list;

    if (node == list->first) {
	list->first = node->next;
    } else {
	node->previous->next = node->next;
    }

    if (node->next == NULL)
	list->last = node->previous;
    else
	node->next->previous = node->previous;

    list->nelems--;
    safe_free(node);

    return list;




}


/**	Remove an element from a list
*	@param list list
*	@param e element
*	@returns the list without the element
*/
list_t *list_remove_elem(list_t * list, void *e)
{

    list_node_t *node = NULL;

    if (list == NULL)
	return list;

    node = list->first;
    while (node != NULL
	   && !(((int (*)(void *, void *)) (list->equal)) (node->elem, e)))
	node = node->next;

    if (node == NULL)
	return list;

    if (node == list->first) {
	list->first = node->next;
    } else {
	node->previous->next = node->next;
    }

    if (node->next == NULL)
	list->last = node->previous;
    else
	node->next->previous = node->previous;

    list->nelems--;
    safe_free(node);

    return list;

}

/**	Gets an element by id
*	@param l list
*	@param id id
*	@returns the element identified by id or NULL if there is none
*/
void *list_get(list_t * l, int id)
{
    list_node_t *node = NULL;

    if (l == NULL)
	return NULL;
    node = l->first;
    while (node != NULL
	   && (((int (*)(void *)) (l->id)) (node->elem) != id))
	node = node->next;

    if (node == NULL)
	return NULL;
    else
	return node->elem;
}

/**	Gets the last element of a list
*	@param l list
*	@returns the last element of the list
*/
void *list_get_last(list_t * l)
{
    if (l == NULL || l->last == NULL)
	return NULL;
    return l->last->elem;
}

/**	Gets the first element of a list
*	@param l list
*	@returns the first element of the list
*/
void *list_get_first(list_t * l)
{
    if (l == NULL || l->first == NULL)
	return NULL;
    return l->first->elem;
}

/**	Returns the number of elements of a list
*	@param l list
*	@returns the number of elements in the list
*/
unsigned int list_nelems(list_t * l)
{
    if (l == NULL)
	return 0;
    return l->nelems;
}

iterator_t *list_iterate_reset(list_t * l)
{

    return creat_iterator(l->first);
}

iterator_t *list_iterate_rewind(list_t * l)
{
    return creat_iterator(l->last);
}

int list_iterate_has_next(iterator_t * i)
{
    return iterator_has_next(i);
}

int list_iterate_has_previous(iterator_t * i)
{
    return iterator_has_previous(i);
}

void *list_iterate_next(iterator_t * i)
{
    return iterator_next(i);
}

void *list_iterate_previous(iterator_t * i)
{
    return iterator_previous(i);
}

void list_iterate_finish(iterator_t * i)
{
    destroy_iterator(i);
}
