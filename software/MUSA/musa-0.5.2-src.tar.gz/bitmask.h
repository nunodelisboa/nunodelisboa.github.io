#ifndef BITMASK_H
#define BITMASK_H

#include "definitions.h"

typedef struct bitmask_str {
    uint size;
    uint blocks;
    mask_t *mask;
} bitmask_t;

bitmask_t *creat_bitmask(uint);
uint bitmask_size(bitmask_t *);
bitmask_t *bitmask_set(bitmask_t *, uint);
bitmask_t *bitmask_unset(bitmask_t *, uint);
bitmask_t *bitmask_and(bitmask_t *, bitmask_t *);
bitmask_t *bitmask_or(bitmask_t *, bitmask_t *);
bool_t bitmask_compare(bitmask_t *, bitmask_t *);
bool_t bitmask_includes(bitmask_t *, bitmask_t *);
bool_t bitmask_isset(bitmask_t *, uint);

bitmask_t *bitmask_clone(bitmask_t *);
void bitmask_destroy(bitmask_t *);
void bitmask_dump(bitmask_t *);

void test_bitmask();

#endif
