#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "list.h"
#include "buflist.h"
#include "util.h"

buflist_t *creat_buflist(bool_t repetition)
{
    buflist_t *list = NULL;
    if (repetition == WITH_REPETITION) {
	list = creat_list((int (*)(void *, void *)) buffer_compare,
			  (int (*)(void *, void *)) buffer_equal,
			  (unsigned int (*)(void *)) buffer_id);
	list->data = (void *) WITH_REPETITION;
    } else {
	list = creat_list((int (*)(void *, void *)) buffer_compare,
			  (int (*)(void *, void *))
			  buffer_equal_norepetition,
			  (unsigned int (*)(void *)) buffer_id);
	list->data = (void *) NO_REPETITION;
    }

    return list;
}

buflist_t *buflist_clone(buflist_t * l)
{
    buflist_t *nl = NULL;
    bufiterator_t *i = NULL;

    if ((uint) l->data == WITH_REPETITION)
	nl = creat_buflist(WITH_REPETITION);
    else
	nl = creat_buflist(NO_REPETITION);
    i = buflist_iterate_reset(l);
    while (buflist_iterate_has_next(i))
	buflist_add_buffer(nl, buflist_iterate_next(i));
    buflist_iterate_finish(i);

    return nl;
}

char *buflist_get_first(buflist_t * l)
{
    if (l == NULL)
	return NULL;
    return (char *) list_get_first(l);
}

void buflist_destroy(buflist_t * l)
{
    list_destroy(l);
}

buflist_t *buflist_add_buffer(buflist_t * list, char *l)
{

    if (list == NULL)
	return list;
    list = list_add_elem_t(list, (void *) l);
    return list;

}

int buflist_nbuffers(buflist_t * list)
{
    if (list == NULL)
	return 0;
    return list_nelems(list);
}

bufiterator_t *buflist_iterate_reset(buflist_t * l)
{
    return list_iterate_reset(l);
}

bufiterator_t *buflist_iterate_rewind(buflist_t * l)
{
    return list_iterate_rewind(l);
}

int buflist_iterate_has_next(bufiterator_t * i)
{
    return list_iterate_has_next(i);
}

int buflist_iterate_has_previous(bufiterator_t * i)
{
    return list_iterate_has_previous(i);
}

char *buflist_iterate_next(bufiterator_t * i)
{
    return (char *) list_iterate_next(i);
}

char *buflist_iterate_previous(bufiterator_t * i)
{
    return (char *) list_iterate_previous(i);
}

void buflist_iterate_finish(bufiterator_t * i)
{
    list_iterate_finish(i);
}

int buffer_compare(char *b1, char *b2)
{
    // do we really need them ordered?
    return strcmp(b1, b2);
}

int buffer_equal(char *b1, char *b2)
{
    /* lists disallow equal elements, this way we circumvent this problem */
    return 0;
}

int buffer_equal_norepetition(char *b1, char *b2)
{
    return !strcmp(b1, b2);
}

int buffer_id(char *b)
{
    return 0;
}
