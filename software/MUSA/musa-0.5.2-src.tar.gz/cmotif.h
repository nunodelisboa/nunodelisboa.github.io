#ifndef CMOTIF_H
#define CMOTIF_H

#include "smotif.h"
#include "smlist.h"
#include "rlist.h"

typedef struct cmotif_str {
    smlist_t *boxes;		// a list of N simple motifs
    rlist_t *ranges;		// a list of N-1 ranges (min,max)
} cmotif_t;

cmotif_t *creat_cmotif(smotif_t *);
cmotif_t *cmotif_add_box(cmotif_t *, smotif_t *, ushort, ushort);
uint cmotif_nboxes(cmotif_t *);
void destroy_cmotif(cmotif_t *);


#endif
