#include <stdlib.h>
#include <stdio.h>

#include "list.h"
#include "ilist.h"
#include "util.h"

ilist_t *creat_ilist(bool_t repetition)
{
    ilist_t *list = NULL;
    if (repetition == WITH_REPETITION) {
	list = creat_list((int (*)(void *, void *)) int_compare,
			  (int (*)(void *, void *)) int_equal,
			  (unsigned int (*)(void *)) int_id);
	list->data = (void *) WITH_REPETITION;
    } else {
	list = creat_list((int (*)(void *, void *)) int_compare,
			  (int (*)(void *, void *)) int_equal_norepetition,
			  (unsigned int (*)(void *)) int_id);
	list->data = (void *) NO_REPETITION;
    }

    return list;
}

ilist_t *ilist_clone(ilist_t * l)
{
    ilist_t *nl = NULL;
    iiterator_t *i = NULL;

    if ((uint) l->data == WITH_REPETITION)
	nl = creat_ilist(WITH_REPETITION);
    else
	nl = creat_ilist(NO_REPETITION);
    i = ilist_iterate_reset(l);
    while (ilist_iterate_has_next(i))
	ilist_add_int(nl, ilist_iterate_next(i));
    ilist_iterate_finish(i);

    return nl;
}

int ilist_get_first(ilist_t * l)
{
    if (l == NULL)
	return -1;
    return (int) list_get_first(l);
}

int ilist_get(ilist_t * l, uint id)
{
    if (l == NULL)
	return -1;
    return (int) list_get(l, id);
}

void ilist_destroy(ilist_t * l)
{
    list_destroy(l);
}

ilist_t *ilist_add_int(ilist_t * list, int l)
{

    if (list == NULL)
	return list;
    list = list_add_elem_t(list, (void *) l);
    return list;

}

ilist_t *ilist_remove_int(ilist_t * list, int l)
{

    if (list == NULL)
	return list;
    list = list_remove_elem(list, (void *) l);
    return list;

}

int ilist_nints(ilist_t * list)
{
    if (list == NULL)
	return 0;
    return list_nelems(list);
}

iiterator_t *ilist_iterate_reset(ilist_t * l)
{
    return list_iterate_reset(l);
}

iiterator_t *ilist_iterate_rewind(ilist_t * l)
{
    return list_iterate_rewind(l);
}

int ilist_iterate_has_next(iiterator_t * i)
{
    return list_iterate_has_next(i);
}

int ilist_iterate_has_previous(iiterator_t * i)
{
    return list_iterate_has_previous(i);
}

int ilist_iterate_next(iiterator_t * i)
{
    return (int) list_iterate_next(i);
}

int ilist_iterate_previous(iiterator_t * i)
{
    return (int) list_iterate_previous(i);
}

void ilist_iterate_finish(iiterator_t * i)
{
    list_iterate_finish(i);
}

int int_compare(int l1, int l2)
{
    return ((int_id(l1) < int_id(l2)) ? -1 : (int_id(l1) ==
					      int_id(l2) ? 0 : 1));
}

int int_equal(int l1, int l2)
{
    /* lists disallow equal elements, this way we circumvent this problem */
    return 0;
}

int int_equal_norepetition(int l1, int l2)
{
    return l1 == l2;
}

int int_id(int i)
{
    return (i);
}
