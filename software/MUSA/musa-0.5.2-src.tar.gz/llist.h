#ifndef LLIST_H
#define LLIST_H

#include "list.h"
#include "literal.h"

typedef list_t llist_t;
typedef iterator_t literator_t;

llist_t *creat_llist();
llist_t *llist_clone(llist_t *);
void llist_destroy(llist_t *);
llist_t *llist_add_literal(llist_t *, literal_t *);
literal_t *llist_get_first(llist_t *);
literal_t *llist_get_last(llist_t *);
literal_t *llist_get(llist_t *, unsigned int);
llist_t *llist_remove_literal(llist_t *, literal_t *);
llist_t *llist_remove_literal_id(llist_t *, unsigned int);
int llist_nliterals(llist_t *);

literator_t *llist_iterate_reset(llist_t *);
literator_t *llist_iterate_rewind(llist_t *);
int llist_iterate_has_next(literator_t *);
int llist_iterate_has_previous(literator_t *);
literal_t *llist_iterate_next(literator_t *);
literal_t *llist_iterate_previous(literator_t *);
void llist_iterate_finish(literator_t *);

#endif
