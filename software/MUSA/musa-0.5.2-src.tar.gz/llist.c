#include <stdlib.h>
#include <stdio.h>
#include "list.h"
#include "llist.h"
#include "literal.h"
#include "utils.h"

llist_t *creat_llist()
{
    llist_t *list = NULL;
    list = (llist_t *) safe_malloc(sizeof(llist_t));
    list = creat_list((int (*)(void *, void *)) literal_compare,
		      (int (*)(void *, void *)) literal_equal,
		      (unsigned int (*)(void *)) literal_id);
    return list;
}

llist_t *llist_clone(llist_t * l)
{
    llist_t *nl = NULL;
    literator_t *i = NULL;

    nl = creat_llist();
    i = llist_iterate_reset(l);
    while (llist_iterate_has_next(i))
	llist_add_literal(nl, literal_clone(llist_iterate_next(i)));
    llist_iterate_finish(i);

    return nl;
}

literal_t *llist_get_first(llist_t * l)
{
    if (l == NULL)
	return NULL;
    return (literal_t *) list_get_first(l);
}

literal_t *llist_get(llist_t * l, unsigned int id)
{
    if (l == NULL)
	return NULL;
    return (literal_t *) list_get(l, id);
}

void llist_destroy(llist_t * l)
{
    list_destroy(l);
}

llist_t *llist_add_literal(llist_t * list, literal_t * l)
{

    if (list == NULL)
	return list;
    list = list_add_elem_t(list, l);
    return list;

}

llist_t *llist_remove_literal(llist_t * list, literal_t * l)
{

    if (list == NULL)
	return list;
    list = list_remove_elem(list, l);
    return list;

}

llist_t *llist_remove_literal_id(llist_t * list, unsigned int id)
{
    if (list == NULL)
	return list;
    list = list_remove_elem_id(list, id);
    return list;
}

int llist_nliterals(llist_t * list)
{
    if (list == NULL)
	return 0;
    return list_nelems(list);
}

literator_t *llist_iterate_reset(llist_t * l)
{
    return list_iterate_reset(l);
}

literator_t *llist_iterate_rewind(llist_t * l)
{
    return list_iterate_rewind(l);
}

int llist_iterate_has_next(literator_t * i)
{
    return list_iterate_has_next(i);
}

int llist_iterate_has_previous(literator_t * i)
{
    return list_iterate_has_previous(i);
}

literal_t *llist_iterate_next(literator_t * i)
{
    return list_iterate_next(i);
}

literal_t *llist_iterate_previous(literator_t * i)
{
    return list_iterate_previous(i);
}

void llist_iterate_finish(literator_t * i)
{
    list_iterate_finish(i);
}

int literal_compare(literal_t * l1, literal_t * l2)
{
    return ((literal_id(l1) < literal_id(l2)) ? -1 : (literal_id(l1) ==
						      literal_id(l2) ? 0 :
						      1));
}

int literal_equal(literal_t * l1, literal_t * l2)
{
    return (literal_sid(l1) == literal_sid(l2));
}
