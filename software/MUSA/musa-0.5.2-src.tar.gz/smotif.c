#include "smotif.h"
#include <string.h>

smotif_t *creat_smotif(char *word, ushort deg)
{
    smotif_t *sm = NULL;

    sm = (smotif_t *) safe_malloc(sizeof(smotif_t));
    sm->word = (char *) safe_malloc(sizeof(char) * (strlen(word) + 1));
    strcpy(sm->word, word);
    sm->deg = deg;

    return sm;
}

void destroy_smotif(smotif_t * sm)
{
    if (sm == NULL)
	return;
    safe_free(sm->word);
    safe_free(sm);
}
