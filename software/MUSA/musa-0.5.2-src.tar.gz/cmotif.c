#include "cmotif.h"

cmotif_t *creat_cmotif(smotif_t * sm)
{

    cmotif_t *cm = NULL;

    cm = (cmotif_t *) safe_malloc(sizeof(cmotif_t));
    cm->boxes = creat_smlist();
    smlist_add_smotif(cm->boxes, sm);
    cm->ranges = creat_rlist();

    return cm;
}


cmotif_t *cmotif_add_box(cmotif_t * cm, smotif_t * sm, ushort mindist,
			 ushort maxdist)
{

    smlist_add_smotif(cm->boxes, sm);
    rlist_add_range(cm->ranges, creat_range(mindist, maxdist));

    return cm;

}

uint cmotif_nboxes(cmotif_t * cm)
{
    return smlist_nsmotifs(cm->boxes);
}

void destroy_cmotif(cmotif_t * cm)
{
    if (cm == NULL)
	return;

    smlist_deep_destroy(cm->boxes);
    rlist_deep_destroy(cm->ranges);
    safe_free(cm);
}
