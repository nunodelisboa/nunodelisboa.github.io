#include <string.h>
#include "matcher.h"
#include "definitions.h"
#include "util.h"
#include "debug.h"

#define LEFT(X)       ((X)&(-(X)))
#define LPOP(X)       ((X)&((X)-1))
#define Win(I,J)      (win[((I)%ws)*(k+1)+(J)])
#define BoxMask(BOX)  ((bbit + (vbit[(BOX)]>>(vgap[(BOX)]))) ^ bbit)


mrlist_t *match(mrlist_t * mr, dataset_t * ds, bool_t bothstrands)
{
    motif_report_t *m = NULL;
    mriterator_t *i = NULL;
    occseq_t *occseq = NULL;
    olist_t *ol = NULL;
    char *seq = NULL;
    uint j = 0;

    i = mrlist_iterate_reset(mr);
    while (mrlist_iterate_has_next(i)) {
	m = mrlist_iterate_next(i);
#ifdef MUSA_DEBUG
	message_l("Analyzing...");
//      print_motif_report(m);
#endif

	ol = creat_olist();
	for (j = 0; j < ds->seqn; j++) {
#ifdef MUSA_DEBUG
	    message("\tGoing for sequence %d", j);
#endif

	    seq = ds->sequences[j];
	    occseq = creat_occseq(j);
	    search(m, seq, occseq_poslist(occseq, FORWARD_STRAND));

	    if (bothstrands) {
		seq = reverse_seq(seq);
		search(m, seq, occseq_poslist(occseq, REVERSE_STRAND));
		safe_free(seq);
	    }

	    if (ilist_nints(occseq_poslist(occseq, FORWARD_STRAND)) > 0
		|| ilist_nints(occseq_poslist(occseq, REVERSE_STRAND)) > 0)
		olist_add_occseq(ol, occseq);
	    else
		destroy_occseq(occseq);
	}
	m->occurrences = ol;
    }
    mrlist_iterate_finish(i);

    return mr;
}

static inline uint fastlog2(uint n)
{
    uint *p, res;
    float t;
    t = (float) n;
    p = (uint *) & t;
    res = (((*p) >> 23) + 1) & 0x7F;
    return res - ((1 << res) & n ? 0 : 1);
}

sa_data_t *compute_sa_data(motif_report_t * mr)
{
    sa_data_t *sa = NULL;
    char *tp = NULL, *tw = NULL;
    smotif_t *sm = NULL;
    range_t *range = NULL;
    smiterator_t *si = NULL;
    riterator_t *ri = NULL;
    uint tlen = 0, clen = 0;
    uint bcount = 0;

    sa = (sa_data_t *) safe_malloc(sizeof(sa_data_t));

    if (motif_report_type(mr) == MOTIF_SIMPLE) {
	sa->l = 1;
	sa->k = mr->mdata.simple_motif->deg;
	sa->P = invert_seq(mr->mdata.simple_motif->word);
	sa->m = strlen(sa->P);
	sa->F = 0x01 << ((sa->m - 1) % (sizeof(uint) * 8));
	sa->mgap = NULL;
	sa->vgap = NULL;
    } else {
	sa->l = cmotif_nboxes(mr->mdata.complex_motif);
	si = smlist_iterate_rewind(mr->mdata.complex_motif->boxes);
	ri = rlist_iterate_rewind(mr->mdata.complex_motif->ranges);

	sa->mgap = (uint *) safe_calloc(sa->l - 1, sizeof(uint));
	sa->vgap = (uint *) safe_calloc(sa->l - 1, sizeof(uint));
	sa->F = 0x00;
	sa->k = 0;

	tp = (char *) safe_malloc(sizeof(char) * 64);
	while (smlist_iterate_has_previous(si)) {
	    bcount++;
	    sm = smlist_iterate_previous(si);
	    tw = invert_seq(sm->word);
	    clen = strlen(sm->word);
	    strcpy(tp + tlen, tw);
	    tlen += clen;
	    safe_free(tw);
	    sa->k += sm->deg;
	    if (bcount > 1) {
		range = rlist_iterate_previous(ri);
		sa->mgap[bcount - 2] = range->min + clen;
		sa->vgap[bcount - 2] = range->max - range->min;
	    }

	    sa->F |= 0x01 << ((tlen - 1) % (sizeof(uint) * 8));
#ifdef MUSA_DEBUG
	    message("pos F = %u, tlen = %u", sa->F, tlen);
#endif

	}
	smlist_iterate_finish(si);
	rlist_iterate_finish(ri);
	tp[tlen] = '\0';
	sa->P = tp;
	sa->m = tlen;

    }


    return sa;
}


void destroy_sa_data(sa_data_t * sa)
{
    if (sa == NULL)
	return;
    safe_free(sa->P);
    safe_free(sa->mgap);
    safe_free(sa->vgap);
    safe_free(sa);

}

ilist_t *search(motif_report_t * mr, char *seq, ilist_t * list)
{

    /** total boxes lenght < 32 **/

    int n = 0;			/* text size */
    int m = 0;			/* total motif size (gaps notwithstanding) */
    int k = 0;			/* number of overall errors */
    char *P = NULL;		/* pattern (concatenated boxes -- reversed) */
    char *T = NULL;		/* text (sequence) */
    char bit2box[32];		/* in which box is a given bit */
    uint i = 0, j = 0, e = 0, h = 0, mask = 0;
    uint *S = NULL;		/* automaton */
    uint V = 0, W = 0;		/* memoize */
    uint B = 0;			/* box begin */
    uint F = 0;			/* box end (mask with "1" bits on ending character of each box) */
    uint l = 0;			/* number of boxes */
    uint *mgap = NULL;		/* mininum gap (mingap + size of next box) */
    uint *vgap = NULL;		/* gap variation */
    uint *vbit = NULL;		/* where is the variation bit in a given box */
    uint bbit = 0;		/* bounding bits */
    uint ws = 0;		/* window size */
    uint *win = NULL;		/* sliding window */
    uint box = 0;		/* box = bit2box[fastlog2(LEFT(h))] */
    uint Sigma[255];		/* Sigma - letter masks */

    sa_data_t *sa = NULL;

    n = strlen(seq);
    T = seq;
    sa = compute_sa_data(mr);
    k = sa->k;
    P = sa->P;
    m = sa->m;
    l = sa->l;
    F = sa->F;
    mgap = sa->mgap;
    vgap = sa->vgap;

    if (m > n) {
	destroy_sa_data(sa);
	return list;
    }

    if (m >= 32)
	error("Pattern is too big! Results are unpredictable");

    B = (F << 1) | 1;

    if (l > 1)
	vbit = (uint *) safe_calloc(l - 1, sizeof(uint));


    bbit = 0;
    mask = 1;
    i = 0;
    ws = 0;
    while (i < l - 1) {
	mask = mask << (vgap[i] + 1);
	vbit[i] = mask >> 1;
	bbit |= vbit[i];
	ws += mgap[i] + vgap[i];
	i++;
    }

    ws -= vgap != NULL ? vgap[0] : 0;
    ws += m - fastlog2(LEFT(F));
    bbit = ~bbit;

    win = (uint *) safe_calloc(ws * (k + 1), sizeof(uint));

    /* bit2box preprocess */
    mask = 1;
    j = 0;
    i = 0;
    while (i < 32) {
	bit2box[i] = j;
	if (F & mask) {
	    j++;
	}
	mask = (mask << 1);
	i++;
    }


    /* Sigma preprocess */
    S = (uint *) safe_calloc(k + 1, sizeof(uint));

    memset(Sigma, 0, 255 * sizeof(uint));

    mask = 1;
    i = 0;
    while (i < m) {
	Sigma[(uint) P[i]] |= mask;
	mask = (mask << 1);
	i++;
    }

    i = 0;
    memset(S, 0, k * sizeof(uint));

    if (l == 1) {
	/* Simple motif */

	mask = mask >> 1;

	while (i < n) {
	    V = S[0];
	    /* reversed scanning */
	    S[0] = ((S[0] << 1) | 1) & Sigma[(uint) T[n - i - 1]];
	    j = 1;
	    while (j <= k) {
		W = S[j];
		/* reversed scanning */
		S[j] =
		    ((S[j] << 1) & Sigma[(uint) T[n - i - 1]]) | (V << 1);
		V = W;
		j++;
	    }

	    j = 0;
	    while (j <= k) {
		if (S[j] & mask) {
#ifdef MUSA_DEBUG
		    message("\t\t\tFound at %u", n - i - 1);
#endif
		    ilist_add_int(list, n - i - 1);
		}
		j++;
	    }
	    i++;
	}

    }


    else {

	while (i < n) {
	    V = 0;
	    mask = B;
	    j = 0;
	    do {
		W = S[j];
		/* reversed scanning to get the start position */
		S[j] =
		    (((S[j] << 1) | mask) & Sigma[(uint) T[n - i - 1]]) |
		    (V << 1);
		V = W;
		mask = 0;
		Win(i, j) = (Win(i - 1, j) >> 1) & bbit;
		j++;
	    }
	    while (j <= k);
	    j = 0;
	    do {
		h = S[j] & F;
		while (h) {
		    box = bit2box[fastlog2(LEFT(h))];
		    if (box == 0) {
			Win(i, j) |= vbit[box];
		    } else {
			e = 0;
			while (j + e <= k) {
			    if (BoxMask(box - 1) &
				Win(i - mgap[box - 1], e)) {
				if (box == l - 1) {
				    ilist_add_int(list, n - i - 1);
#ifdef MUSA_DEBUG
				    message("\t\t\tFound at: %u",
					    n - i - 1);
#endif
				} else {
				    Win(i, j + e) |= vbit[box];
				}
			    }
			    e++;
			}

		    }
		    h = LPOP(h);
		}
		j++;
	    }
	    while (j <= k);
	    i++;
	}

    }

    safe_free(S);
    safe_free(vbit);
    safe_free(win);
    destroy_sa_data(sa);
    return list;
}
