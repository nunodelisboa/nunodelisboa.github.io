#ifndef SMOTIF_H
#define SMOTIF_H

#include "definitions.h"

typedef struct smotif_str {
    char *word;
    ushort deg;
} smotif_t;

smotif_t *creat_smotif(char *, ushort);
void destroy_smotif(smotif_t *);


#endif
