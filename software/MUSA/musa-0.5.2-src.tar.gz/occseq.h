#ifndef OCCSEQ_H
#define OCCSEQ_H

#include "ilist.h"

typedef enum occ_direction_en { FORWARD_STRAND,
    REVERSE_STRAND
} occ_direction_t;

typedef struct occseq_str {
    ushort seqn;
    ilist_t *pos_forward;
    ilist_t *pos_reverse;
} occseq_t;

occseq_t *creat_occseq(ushort seqn);
occseq_t *occseq_clone(occseq_t *);
occseq_t *occseq_add_pos(occseq_t *, uint pos, occ_direction_t dir);
ilist_t *occseq_poslist(occseq_t *, occ_direction_t dir);
void destroy_occseq(occseq_t *);



#endif
