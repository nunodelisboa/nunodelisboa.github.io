#ifndef MRLIST_H
#define MRLIST_H

#include "list.h"
#include "motif_report.h"

typedef list_t mrlist_t;
typedef iterator_t mriterator_t;

mrlist_t *creat_mrlist();
void mrlist_destroy(mrlist_t *);
mrlist_t *mrlist_add_motif_report(mrlist_t *, motif_report_t *);
mrlist_t *mrlist_remove_motif_report(mrlist_t *, motif_report_t *);
motif_report_t *mrlist_get_last(mrlist_t *);
unsigned int mrlist_nmotif_reports(mrlist_t *);
int motif_report_compare(motif_report_t *, motif_report_t *);
int motif_report_equal(motif_report_t *, motif_report_t *);
int motif_report_id(motif_report_t *);
mriterator_t *mrlist_iterate_reset(mrlist_t *);
int mrlist_iterate_has_next(mriterator_t *);
motif_report_t *mrlist_iterate_next(mriterator_t *);
void mrlist_iterate_finish(mriterator_t *);

#endif
