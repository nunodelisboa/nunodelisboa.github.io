#include <stdlib.h>
#include <stdio.h>
#include <assert.h>

#include "biclustering.h"
#include "slist.h"
#include "blist.h"
#include "buflist.h"
#include "matrix.h"
#include "definitions.h"
#include "options.h"
#include "assembly.h"
#include "debug.h"

extern options_t options;

slist_t *generate_seeds(matrix_t * m, ushort sieve)
{

    motif_t m1 = 0, m2 = 0;
    score_t score = 0;
    slist_t *s = NULL;
    bitmask_t *mask = NULL;

    if (m == NULL)
	return NULL;

    s = creat_slist();

    for (m1 = 0; m1 < MERS(options.lambda); m1++) {
	for (m2 = 0; m2 <= m1; m2++) {
	    score = m->entries[m1][m2]->score;
	    if (score >= sieve) {
		say("\r %.2f%% Adding seed for (%d,%d) with score %d",
		    (float) ((float) ((m1 + 1) * 100)) /
		    ((float) MERS(options.lambda)), m1, m2, score);
		mask = creat_bitmask(MERS(options.lambda));
		bitmask_set(mask, m1);
		bitmask_set(mask, m2);
		slist_add_seed(s, creat_seed(score, m1 == m2, mask));
	    }

	}
    }
    say_nl();

    return s;
}

void destroy_seeds(slist_t * s)
{
    siterator_t *i = NULL;

    if (s == NULL)
	return;

    i = slist_iterate_reset(s);
    while (slist_iterate_has_next(i)) {
	destroy_seed(slist_iterate_next(i));
    }
    slist_iterate_finish(i);
    slist_destroy(s);
}

blist_t *extract_biclusters(matrix_t * m, slist_t * s)
{

    blist_t *b = NULL;
    blist_t **stack = NULL;
    siterator_t *siter = NULL;
    bicluster_t *bicluster = NULL, *hip = NULL;
    int i = 0;
    int progress = 0, seedn = 0;

    b = creat_blist();
    stack =
	(blist_t **) safe_malloc(sizeof(blist_t *) * (options.seqn + 1));

    for (i = 0; i <= options.seqn; i++) {
	stack[i] = NULL;
    }

    seedn = slist_nseeds(s);
    siter = slist_iterate_reset(s);
    while (slist_iterate_has_next(siter)) {
	message_l("\r%.2f%% ",
		  (float) ((float) ((++progress) * 100)) /
		  ((float) seedn));
	bicluster =
	    creat_bicluster_from_seed(slist_iterate_next(siter), m);
	if (!check_bicluster(bicluster, stack)) {
	    bicluster_deep_destroy(bicluster);
	    continue;
	}

	hip = bicluster_clone(bicluster);

	for (i = 0; i < MERS(options.lambda); i++) {
	    bicluster_set_rc(hip, i);
	    if (bicluster_is_constant(hip)) {
		bicluster_deep_destroy(bicluster);
		bicluster = hip;
		hip = bicluster_clone(bicluster);
	    } else {
		if (bicluster_isset_diag(hip, i)) {
		    message("Regretting about rc=%d", i);
		    bicluster_dump(hip);
		    bicluster_print(hip);
		}
		bicluster_unset_rc(hip, i);
	    }
	}


	for (i = 0; i < MERS(options.lambda); i++) {
	    if (bicluster_isset_rc(hip, i)) {
		bicluster_set_diag(hip, i);
		if (bicluster_is_constant(hip)) {
		    bicluster_deep_destroy(bicluster);
		    bicluster = hip;
		    hip = bicluster_clone(bicluster);
		} else
		    bicluster_unset_diag(hip, i);
	    }
	}

	bicluster_deep_destroy(hip);

	message_l("Adding bicluster %d", bicluster->id);

	blist_add_bicluster(b, bicluster);

	if (stack[bicluster->score] == NULL) {
	    stack[bicluster->score] = creat_blist();
	}

	blist_add_bicluster(stack[bicluster->score], bicluster);


    }

    slist_iterate_finish(siter);

    for (i = 0; i <= options.seqn; i++) {
	if (stack[i] != NULL) {
	    blist_destroy(stack[i]);
	}
    }

    safe_free(stack);

#ifdef MUSA_DEBUG
    assert(blist_nbiclusters(b) == 0
	   || bicluster_is_constant(blist_get_first(b)));
#endif

    return b;
}


bool_t check_bicluster(bicluster_t * bi, blist_t ** stack)
{
    blist_t *b = NULL;
    biterator_t *biter = NULL;
    uint result = 1;

    if (bi->score > options.seqn)
	message("check_bicluster: accessing stack[%d] : illegal index",
		bi->score);

    b = stack[bi->score];
    if (b == NULL)
	return result;

    biter = blist_iterate_reset(b);
    while (blist_iterate_has_next(biter)) {
	if (bicluster_includes(blist_iterate_next(biter), bi)) {
	    result = 0;
	    break;
	}
    }
    blist_iterate_finish(biter);

    return result;
}

void dump_biclusters(blist_t * bl)
{
    biterator_t *biter = NULL;
    bicluster_t *b = NULL;

    fprintf(options.output_file, "# MUSA/0.5.2 Debug Output\n");
    fprintf(options.output_file, "# Sequences: %d Motifs: %d\n",
	    options.seqn, blist_nbiclusters(bl));

    biter = blist_iterate_reset(bl);
    while (blist_iterate_has_next(biter)) {
	b = blist_iterate_next(biter);
#ifdef MUSA_DEBUG
	assert(bicluster_is_constant(b));
	bicluster_print(b);
	fprintf(stdout, "BICLUSTER(%d) ASSEMBLY: %s\n", b->id,
		motif_assembly(b));
#else
	motif_assembly(b);
#endif


    }
    blist_iterate_finish(biter);

    return;
}

mrlist_t *generate_mrlist(blist_t * bl)
{
    biterator_t *biter = NULL;
    bicluster_t *b = NULL;
    buflist_t *bufall = NULL;
    buflist_t *bufuniq = NULL;
    bufiterator_t *i = NULL;
    char *buffer = NULL;
    mrlist_t *mr = NULL;
    motif_report_t *report = NULL;

    mr = creat_mrlist();
    bufall = creat_buflist(WITH_REPETITION);
    bufuniq = creat_buflist(NO_REPETITION);

    biter = blist_iterate_reset(bl);
    while (blist_iterate_has_next(biter)) {
	b = blist_iterate_next(biter);
	buffer = motif_assembly(b);
	buflist_add_buffer(bufall, buffer);
	buflist_add_buffer(bufuniq, buffer);
    }
    blist_iterate_finish(biter);

    i = buflist_iterate_reset(bufuniq);
    while (buflist_iterate_has_next(i)) {
	buffer = buflist_iterate_next(i);
	report = buffer2motif_report(buffer);
#ifdef MUSA_DEBUG
	message("buffer: %s", buffer);
	message("report:");
//      print_motif_report(report);
#endif
	mrlist_add_motif_report(mr, report);
    }
    buflist_iterate_finish(i);

    i = buflist_iterate_reset(bufall);
    while (buflist_iterate_has_next(i)) {
	safe_free(buflist_iterate_next(i));
    }
    buflist_iterate_finish(i);

    buflist_destroy(bufall);
    buflist_destroy(bufuniq);

    return mr;

}
