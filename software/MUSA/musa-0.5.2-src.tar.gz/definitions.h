#ifndef DEFINITIONS_H
#define DEFINITIONS_H

#include "util.h"

#define MERS(n) ipow(4,n)
#define QUIET	options.quiet

/* Default values */
#define DEFAULT_MAXDIST		500
#define DEFAULT_MINDIST 	1
#define DEFAULT_EPSILON 	0
#define DEFAULT_LAMBDA 		4
#define DEFAULT_SIEVERATE 	30

typedef unsigned int uint;
typedef unsigned short ushort;
typedef unsigned int mask_t;
typedef unsigned char bool_t;
typedef short distance_t;
typedef unsigned int position_t;
typedef unsigned short score_t;
typedef unsigned short motif_t;


#endif
