#include <stdio.h>
#include <stdlib.h>
#include "list.h"
#include "clist.h"
#include "configuration.h"
#include "util.h"

clist_t *creat_clist()
{
    return (clist_t *) creat_list((int (*)(void *, void *))
				  configuration_compare,
				  (int (*)(void *, void *))
				  configuration_equal,
				  (unsigned int (*)(void *))
				  configuration_id);
}

void clist_destroy(clist_t * l)
{
    list_destroy(l);
}


clist_t *clist_add_configuration(clist_t * l, configuration_t * c)
{
    return (clist_t *) list_add_elem(l, c);
}

clist_t *clist_remove_configuration(clist_t * l, configuration_t * c)
{
    return (clist_t *) list_remove_elem(l, c);
}

uint clist_nconfigurations(clist_t * l)
{
    return list_nelems(l);
}

configuration_t *clist_get(clist_t * l, unsigned int id)
{
    return (configuration_t *) list_get(l, id);
}

int configuration_compare(configuration_t * c1, configuration_t * c2)
{

    return
	c1->score < c2->score ?
	-1 :
	(c1->score > c2->score ?
	 1 :
	 (c1->motif1 < c2->motif1 ?
	  -1 :
	  (c1->motif1 > c2->motif1 ?
	   1 :
	   (abs(c1->distance) > abs(c2->distance) ?
	    -1 :
	    (abs(c1->distance) < abs(c2->distance) ?
	     1 :
	     (c1->motif2 < c2->motif2 ?
	      -1 : (c1->motif2 > c2->motif2 ? 1 : 0)))))));


}

int configuration_equal(configuration_t * c1, configuration_t * c2)
{
    return c1->motif1 == c2->motif1 && c1->motif2 == c2->motif2
	&& c1->distance == c2->distance && c1->score == c2->score;
}

citerator_t *clist_iterate_reset(clist_t * l)
{
    return list_iterate_reset(l);
}

citerator_t *clist_iterate_rewind(clist_t * l)
{
    return list_iterate_rewind(l);
}

int clist_iterate_has_next(citerator_t * i)
{
    return list_iterate_has_next(i);
}

int clist_iterate_has_previous(citerator_t * i)
{
    return list_iterate_has_previous(i);
}

configuration_t *clist_iterate_next(citerator_t * i)
{
    return (configuration_t *) list_iterate_next(i);
}

configuration_t *clist_iterate_previous(citerator_t * i)
{
    return (configuration_t *) list_iterate_previous(i);
}

void clist_iterate_finish(citerator_t * i)
{
    list_iterate_finish(i);
}

configuration_t *clist_get_first(clist_t * l)
{
    return (configuration_t *) list_get_first(l);
}

configuration_t *clist_get_last(clist_t * l)
{
    return (configuration_t *) list_get_last(l);
}

uint configuration_id(configuration_t * c)
{
    return c->id;
}
