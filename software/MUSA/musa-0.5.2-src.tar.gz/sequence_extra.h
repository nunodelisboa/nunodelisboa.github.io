#ifndef SEQUENCE_EXTRA_H
#define SEQUENCE_EXTRA_H

char *reverse_seq(char *);
char *invert_seq(char *);

#endif
