#include <stdio.h>
#include <stdlib.h>
#include "list.h"
#include "smlist.h"
#include "smotif.h"
#include "util.h"

smlist_t *creat_smlist()
{
    return (smlist_t *) creat_list((int (*)(void *, void *))
				   smotif_compare,
				   (int (*)(void *, void *))
				   smotif_equal, (unsigned int (*)(void *))
				   smotif_id);
}

void smlist_destroy(smlist_t * l)
{
    list_destroy(l);
}

void smlist_deep_destroy(smlist_t * l)
{
    smiterator_t *i = NULL;

    i = smlist_iterate_reset(l);
    while (smlist_iterate_has_next(i))
	destroy_smotif(smlist_iterate_next(i));

    smlist_iterate_finish(i);
    smlist_destroy(l);
}


smlist_t *smlist_add_smotif(smlist_t * l, smotif_t * sm)
{
    return (smlist_t *) list_add_elem(l, sm);
}

unsigned int smlist_nsmotifs(smlist_t * l)
{
    return list_nelems(l);
}

int smotif_compare(smotif_t * sm1, smotif_t * sm2)
{
    return 0;
}

int smotif_equal(smotif_t * sm1, smotif_t * sm2)
{
    return 0;
}

int smotif_id(smotif_t * sm)
{
    return 0;
}

smiterator_t *smlist_iterate_reset(smlist_t * l)
{
    return list_iterate_reset(l);
}

smiterator_t *smlist_iterate_rewind(smlist_t * l)
{
    return list_iterate_rewind(l);
}

int smlist_iterate_has_next(smiterator_t * i)
{
    return list_iterate_has_next(i);
}

int smlist_iterate_has_previous(smiterator_t * i)
{
    return list_iterate_has_previous(i);
}

smotif_t *smlist_iterate_next(smiterator_t * i)
{
    return (smotif_t *) list_iterate_next(i);
}

smotif_t *smlist_iterate_previous(smiterator_t * i)
{
    return (smotif_t *) list_iterate_previous(i);
}

void smlist_iterate_finish(smiterator_t * i)
{
    list_iterate_finish(i);
}

smotif_t *smlist_get_first(smlist_t * l)
{
    return (smotif_t *) list_get_first(l);
}

smotif_t *smlist_get_last(smlist_t * l)
{
    return (smotif_t *) list_get_last(l);
}
