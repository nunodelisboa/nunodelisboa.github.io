#ifndef BICLUSTER_H
#define BICLUSTER_H

#include "seed.h"
#include "definitions.h"
#include "bitmask.h"
#include "matrix.h"

typedef struct bicluster_str {
    uint id;
    bitmask_t *I;
    bitmask_t *L;
    matrix_t *m;
    score_t score;
} bicluster_t;

bicluster_t *creat_bicluster(bitmask_t *, bitmask_t *, matrix_t *,
			     score_t);
bicluster_t *_creat_bicluster(uint, bitmask_t *, bitmask_t *, matrix_t *,
			      score_t);
bicluster_t *creat_bicluster_from_seed(seed_t *, matrix_t *);
void bicluster_deep_destroy(bicluster_t *);
bicluster_t *bicluster_clone(bicluster_t *);
bool_t bicluster_includes(bicluster_t *, bicluster_t *);
bool_t bicluster_is_constant(bicluster_t *);

bicluster_t *bicluster_set_rc(bicluster_t *, motif_t);
bool_t bicluster_isset_rc(bicluster_t *, motif_t);
bicluster_t *bicluster_set_diag(bicluster_t *, motif_t);
bool_t bicluster_isset_diag(bicluster_t *, motif_t);
bicluster_t *bicluster_unset_rc(bicluster_t *, motif_t);
bicluster_t *bicluster_unset_diag(bicluster_t *, motif_t);

uint bicluster_size(bicluster_t *);

void bicluster_print(bicluster_t *);
void bicluster_dump(bicluster_t *);


#endif
