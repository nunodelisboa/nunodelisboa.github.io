#ifndef RLIST_H
#define RLIST_H

#include "list.h"
#include "range.h"

typedef list_t rlist_t;
typedef iterator_t riterator_t;

rlist_t *creat_rlist();
rlist_t *rlist_clone(rlist_t *);
void rlist_destroy(rlist_t *);
void rlist_deep_destroy(rlist_t *);
rlist_t *rlist_add_range(rlist_t *, range_t *);
range_t *rlist_get_first(rlist_t *);
range_t *rlist_get_last(rlist_t *);
int rlist_nranges(rlist_t *);

riterator_t *rlist_iterate_reset(rlist_t *);
riterator_t *rlist_iterate_rewind(rlist_t *);
int rlist_iterate_has_next(riterator_t *);
int rlist_iterate_has_previous(riterator_t *);
range_t *rlist_iterate_next(riterator_t *);
range_t *rlist_iterate_previous(riterator_t *);
void rlist_iterate_finish(riterator_t *);

int range_compare(range_t *, range_t *);
int range_equal(range_t *, range_t *);
int range_id(range_t *);

#endif
