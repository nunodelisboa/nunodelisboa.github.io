#ifndef BLIST_H
#define BLIST_H

#include "list.h"
#include "bicluster.h"

typedef list_t blist_t;
typedef iterator_t biterator_t;

blist_t *creat_blist();
blist_t *blist_clone(blist_t *);
void blist_destroy(blist_t *);
void blist_deep_destroy(blist_t *);
blist_t *blist_add_bicluster(blist_t *, bicluster_t *);
bicluster_t *blist_get_first(blist_t *);
bicluster_t *blist_get_last(blist_t *);
bicluster_t *blist_get(blist_t *, uint);
blist_t *blist_remove_bicluster(blist_t *, bicluster_t *);
uint blist_nbiclusters(blist_t *);

biterator_t *blist_iterate_reset(blist_t *);
biterator_t *blist_iterate_rewind(blist_t *);
bool_t blist_iterate_has_next(biterator_t *);
bool_t blist_iterate_has_previous(biterator_t *);
bicluster_t *blist_iterate_next(biterator_t *);
bicluster_t *blist_iterate_previous(biterator_t *);
void blist_iterate_finish(biterator_t *);

int bicluster_compare(bicluster_t *, bicluster_t *);
bool_t bicluster_equal(bicluster_t *, bicluster_t *);
score_t bicluster_id(bicluster_t *);

#endif
