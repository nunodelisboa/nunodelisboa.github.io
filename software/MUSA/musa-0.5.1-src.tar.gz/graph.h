#ifndef GRAPH_H
#define GRAPH_H

#include "definitions.h"
#include "configuration.h"


typedef struct link_str {
    score_t score;
    uint distance;
    struct gnode_str *target;
    struct link_str *next;
} link_t;

typedef struct gnode_str {
    motif_t id;
    ushort inbound;
    ushort outbound;
    int color;
    struct link_str *short_range;
    struct link_str *long_range;
    struct link_str *self_loop;
    struct gnode_str *next;
} gnode_t;

typedef struct graph_str {
    struct gnode_str *head;
    ushort nnodes;
    int color;
} graph_t;

graph_t *graph_creat();
gnode_t *gnode_creat(motif_t);
link_t *link_creat(score_t, uint, gnode_t *);

graph_t *graph_add_configuration(graph_t *, configuration_t *);
char *graph2motif(graph_t *);

void graph_destroy(graph_t *);
void gnode_destroy(gnode_t *);
void link_destroy(link_t *);

bool_t graph_has_node_id(graph_t *, motif_t);
graph_t *graph_add_node(graph_t *, motif_t);
graph_t *graph_add_link(graph_t *, motif_t, motif_t, uint, score_t);



#endif
