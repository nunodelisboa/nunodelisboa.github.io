#ifndef MATCHER_H
#define MATCHER_H

#include "mrlist.h"
#include "sequences.h"
#include "ilist.h"
#include "motif_report.h"

typedef struct sa_data_str {
    int k;			/* overall errors */
    char *P;			/* reversed pattern of concatenated boxes */
    uint m;			/* total lenght of concatenated boxes */
    uint l;			/* number of boxes */
    uint F;			/* bitmask of box ends in the inverted pattern */
    uint *mgap;			/* mininum gap (mingap + size of next box) */
    uint *vgap;			/* gap variation */
} sa_data_t;

mrlist_t *match(mrlist_t *, dataset_t *, bool_t);
ilist_t *search(motif_report_t *, char *, ilist_t *);
char *reverse_seq(char *);
char *invert_seq(char *);
sa_data_t *compute_sa_data(motif_report_t *);
void destroy_sa_data(sa_data_t *);

#endif
