#include <stdlib.h>
#include <stdio.h>
#include <assert.h>

#include "matrix.h"
#include "ilist.h"
#include "definitions.h"
#include "options.h"
#include "debug.h"

extern options_t options;

matrix_t *generate_matrix(profile_t * p)
{

    int i = 0;
    ilist_t *poslist = NULL;
    ilist_t *entrylist = NULL;
    ilist_t *plist = NULL;
    iiterator_t *iterator = NULL;
    motif_t m1 = 0, m2 = 0;
    score_t maxscore = 0, curscore = 0;
    distance_t curdist = 0, lastdist = 0;
    delta_list_t *d = NULL;
    mentry_t *mentry = NULL;

    matrix_t *matrix = NULL;

    if (p == NULL)
	return NULL;

    matrix = (matrix_t *) safe_malloc(sizeof(matrix_t));


    matrix->entries =
	(mentry_t ***) safe_malloc(sizeof(void *) * MERS(options.lambda));

    for (m1 = 0; m1 < MERS(options.lambda); m1++) {
	matrix->entries[m1] =
	    (mentry_t **) safe_malloc(sizeof(void *) * (m1 + 1));

	say("\r%.2f%%", (float) ((float) ((m1 + 1) * 100)) /
	    ((float) MERS(options.lambda)));

	for (m2 = 0; m2 <= m1; m2++) {

	    poslist = creat_ilist(WITH_REPETITION);
	    d = generate_delta_list(p, m1, m2);
	    for (i = 0; i < options.seqn; i++) {

		plist = d->distances[i];

		if (plist != NULL) {

		    iterator = ilist_iterate_reset(plist);
		    while (ilist_iterate_has_next(iterator)) {
			ilist_add_int(poslist,
				      ilist_iterate_next(iterator));
		    }
		    ilist_iterate_finish(iterator);

		}
	    }
	    destroy_delta_list(d);

	    curscore = 0;
	    maxscore = 0;

	    if (ilist_nints(poslist) > 0) {

		entrylist = creat_ilist(WITH_REPETITION);

		iterator = ilist_iterate_reset(poslist);
		lastdist = ilist_get_first(poslist);
		ilist_add_int(entrylist, lastdist);

		while (ilist_iterate_has_next(iterator)) {
		    curdist = ilist_iterate_next(iterator);

//                  fprintf(stderr, "curdist = %d, lastdist = %d\n",
//                          curdist, lastdist);

		    if (curdist != lastdist) {
			if (curscore == maxscore) {
			    ilist_add_int(entrylist, lastdist);
			} else if (curscore > maxscore) {
			    ilist_destroy(entrylist);
			    entrylist = creat_ilist(WITH_REPETITION);
			    ilist_add_int(entrylist, lastdist);
			    maxscore = curscore;
			}
			curscore = 1;

		    } else
			curscore++;

//                  fprintf(stderr, "curscore = %d, maxscore =%d\n",
//                          curscore, maxscore);
		    lastdist = curdist;
		}
		ilist_iterate_finish(iterator);

		if (curscore == maxscore) {
		    ilist_add_int(entrylist, lastdist);
		} else if (curscore > maxscore) {
		    ilist_destroy(entrylist);
		    entrylist = creat_ilist(WITH_REPETITION);
		    ilist_add_int(entrylist, lastdist);
		    maxscore = curscore;
		}
	    } else
		entrylist = NULL;

	    ilist_destroy(poslist);

	    mentry = (mentry_t *) safe_malloc(sizeof(mentry_t));
	    mentry->score = maxscore;
	    mentry->distances = entrylist;
#ifdef MUSA_DEBUG
	    assert(maxscore == 0 || entrylist != NULL);
#endif

	    matrix->entries[m1][m2] = mentry;
	}
    }

    say_nl();
    return matrix;

}

unsigned int matrix_dim(matrix_t * m)
{
    return MERS(options.lambda);
}

void destroy_matrix(matrix_t * m)
{

    motif_t m1 = 0, m2 = 0;

    if (m == NULL)
	return;

    for (m1 = 0; m1 < MERS(options.lambda); m1++) {
	for (m2 = 0; m2 <= m1; m2++) {
	    if (m->entries[m1][m2]->distances != NULL)
		ilist_destroy(m->entries[m1][m2]->distances);
	    safe_free(m->entries[m1][m2]);
	}
	safe_free(m->entries[m1]);
    }
    safe_free(m->entries);
    safe_free(m);
}
