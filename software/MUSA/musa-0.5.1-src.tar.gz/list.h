#ifndef LIST_H
#define LIST_H

typedef struct list_node_str {
    void *elem;			/**< the element */
    struct list_node_str *next;	/**< the next node */
    struct list_node_str *previous;	/**< the previous node */
} list_node_t;

typedef struct iterator_str {
    struct list_node_str *iterator;
} iterator_t;

iterator_t *creat_iterator(struct list_node_str *);
int iterator_has_next(iterator_t *);
int iterator_has_previous(iterator_t *);
void *iterator_next(iterator_t *);
void *iterator_previous(iterator_t *);
void destroy_iterator(iterator_t *);

typedef struct list_str {
    list_node_t *first;		/**< the first node of the list */
    list_node_t *last;		/**< the last node of the list */
    unsigned int nelems;	/**< the number of elements of the list */
    void *compare;		/**< a comparison function pointer */
    void *equal;		/**< an equality test function pointer */
    void *id;			/**< an id function pointer */
    void *data;			/**< a generic data pointer */
} list_t;

list_node_t *creat_list_node(void *);

list_t *creat_list(int (*)(void *, void *), int (*)(void *, void *),
		   unsigned int (*)(void *));
void list_destroy(list_t *);
list_t *list_add_elem(list_t *, void *);
list_t *list_add_elem_h(list_t *, void *);
list_t *list_add_elem_t(list_t *, void *);
list_t *list_remove_elem(list_t *, void *);
list_t *list_remove_elem_id(list_t *, unsigned int);
void *list_get(list_t *, int);
void *list_get_first(list_t *);
void *list_get_last(list_t *);
unsigned int list_nelems(list_t *);
iterator_t *list_iterate_reset(list_t *);
iterator_t *list_iterate_rewind(list_t *);
int list_iterate_has_next(iterator_t *);
int list_iterate_has_previous(iterator_t *);
void *list_iterate_next(iterator_t *);
void *list_iterate_previous(iterator_t *);
void list_iterate_finish(iterator_t *);


#endif
