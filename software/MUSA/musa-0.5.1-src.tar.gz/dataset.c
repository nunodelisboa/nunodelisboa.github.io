#include <stdlib.h>
#include <stdio.h>
#include "sequences.h"
#include "util.h"

dataset_t *creat_dataset(ushort seqn, char **sequences)
{
    dataset_t *ds = NULL;

    ds = (dataset_t *) safe_malloc(sizeof(dataset_t));
    ds->seqn = seqn;
    ds->sequences = sequences;

    return ds;
}

void destroy_dataset(dataset_t * ds)
{
    int i = 0;

    if (ds == NULL)
	return;

    for (i = 0; i < ds->seqn; i++) {
	if (ds->sequences[i] != NULL)
	    safe_free(ds->sequences[i]);
    }

    safe_free(ds->sequences);
    safe_free(ds);

    return;
}
