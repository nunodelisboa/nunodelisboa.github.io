#ifndef DISTANCE_H
#define DISTANCE_H

#include "definitions.h"

typedef struct range_str {
    ushort min;
    ushort max;
} range_t;

range_t *creat_range(ushort min, ushort max);
range_t *range_clone(range_t * d);
void range_destroy(range_t * d);

#endif
