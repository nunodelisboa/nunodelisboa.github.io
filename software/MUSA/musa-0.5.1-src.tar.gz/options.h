#ifndef OPTIONS_H
#define OPTIONS_H

typedef struct options_str {
    ushort lambda;
    ushort epsilon;
    ushort seqn;
    ushort sieve;
    ushort sieverate;
    bool_t quiet;
    bool_t statistics;
    bool_t dump_mesh;
    bool_t bothstrands;
    distance_t mindist;
    distance_t maxdist;
    FILE *output_file;
} options_t;



#endif
