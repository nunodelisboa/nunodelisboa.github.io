#include <stdio.h>
#include <stdlib.h>
#include <strings.h>
#include "assembly.h"
#include "bicluster.h"
#include "options.h"
#include "matrix.h"
#include "clist.h"
#include "configuration.h"
#include "ilist.h"
#include "graph.h"
#include "debug.h"

extern options_t options;

char *motif_assembly(bicluster_t * b)
{

    uint m1 = 0, m2 = 0;
    clist_t *clist = NULL;
    ilist_t *ilist = NULL;
    iiterator_t *iter = NULL;
    citerator_t *citer = NULL;
    configuration_t *c = NULL;
    distance_t distance = 0, dmax = 0;
    motif_t first_motif = 0;
    char *motif = NULL;
    // int i = 0;
    graph_t *graph = NULL;

    clist = creat_clist();

    for (m1 = 0; m1 < MERS(options.lambda); m1++) {
	if (!bitmask_isset(b->I, m1))
	    continue;
	for (m2 = 0; m2 <= m1; m2++) {
	    if (!bitmask_isset(b->I, m2))
		continue;
	    if (m1 == m2 && !bitmask_isset(b->L, m2))
		continue;

	    ilist = b->m->entries[m1][m2]->distances;
	    iter = ilist_iterate_reset(ilist);

	    while (ilist_iterate_has_next(iter)) {
		distance = ilist_iterate_next(iter);

		clist_add_configuration(clist,
					creat_configuration(m1, m2,
							    distance,
							    b->m->
							    entries[m1]
							    [m2]->score));
	    }

	    ilist_iterate_finish(iter);
	}

    }

/*
    message
	("We are going to merge %d configurations for a bicluster of size %d",
	 clist_nconfigurations(clist), bicluster_size(b));
*/

    graph = graph_creat();

    citer = clist_iterate_reset(clist);
    while (clist_iterate_has_next(citer)) {
	c = clist_iterate_next(citer);
	graph_add_configuration(graph, c);
	/* for each subset of configurations */
	if (abs(c->distance) > dmax) {
	    dmax = abs(c->distance);
	    if (c->distance > 0)
		first_motif = c->motif1;
	    else
		first_motif = c->motif2;

	}
    }
    clist_iterate_finish(citer);
    citer = clist_iterate_reset(clist);
    while (clist_iterate_has_next(citer)) {
	destroy_configuration(clist_iterate_next(citer));
    }
    clist_iterate_finish(citer);
    clist_destroy(clist);

    motif = graph2motif(graph);
    graph_destroy(graph);

    return motif;

}
