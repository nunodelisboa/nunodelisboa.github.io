#include "sequences.h"

#ifndef CONFIGURATION_H
#define CONFIGURATION_H

typedef struct delta_list_str {
    ilist_t **distances;
} delta_list_t;

delta_list_t *generate_delta_list(profile_t *, motif_t, motif_t);
void destroy_delta_list(delta_list_t *);

typedef struct configuration_str {
    uint id;
    motif_t motif1;
    motif_t motif2;
    distance_t distance;
    score_t score;
} configuration_t;

configuration_t *creat_configuration(motif_t, motif_t, distance_t,
				     score_t);
void destroy_configuration(configuration_t *);

#endif
