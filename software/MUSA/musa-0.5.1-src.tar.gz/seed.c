#include <stdlib.h>
#include "seed.h"
#include "bicluster.h"
#include "util.h"
#include "definitions.h"
#include "bitmask.h"

seed_t *creat_seed(score_t score, bool_t is_diag, bitmask_t * mask)
{
    seed_t *seed = NULL;

    seed = (seed_t *) safe_malloc(sizeof(seed_t));
    seed->score = score;
    seed->is_diag = is_diag;
    seed->mask = mask;

    return seed;
}

void destroy_seed(seed_t * s)
{
    if (s == NULL)
	return;
    bitmask_destroy(s->mask);
    safe_free(s);
}
