#ifndef MOTIF_REPORT_H
#define MOTIF_REPORT_H

#include "smotif.h"
#include "cmotif.h"
#include "olist.h"
#include "definitions.h"

typedef enum motif_type_enum { MOTIF_SIMPLE, MOTIF_COMPLEX } motif_type_t;
typedef enum motif_occ_enum { OCC_FORWARD, OCC_REVERSE } motif_occ_t;

typedef double pvalue_t;

typedef struct motif_report_str {
    motif_type_t type;
    union {
	smotif_t *simple_motif;
	cmotif_t *complex_motif;
    } mdata;

    olist_t *occurrences;	// a list of sequences, with a list of pos
    // required by RISO because it is amnesiac
    // required by MUSA because it needs    
    // a reality check
    pvalue_t pvalue;
} motif_report_t;

motif_report_t *creat_motif_report(char *word, ushort error);
motif_report_t *motif_report_add_box(motif_report_t * mr, char *word,
				     ushort mindist, ushort maxdist,
				     ushort error);

motif_report_t *buffer2motif_report(char *);
void print_motif_report(motif_report_t *);
void destroy_motif_report(motif_report_t *);
motif_type_t motif_report_type(motif_report_t *);

#endif
