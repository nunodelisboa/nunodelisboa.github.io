#include <stdlib.h>
#include <strings.h>
#include <stdio.h>
#include <assert.h>

#include "util.h"
#include "bicluster.h"
#include "seed.h"
#include "matrix.h"
#include "bitmask.h"
#include "options.h"
#include "debug.h"

extern options_t options;



bicluster_t *creat_bicluster(bitmask_t * I, bitmask_t * L, matrix_t * m,
			     score_t score)
{
    static uint next_id = 0;
    return _creat_bicluster(++next_id, I, L, m, score);
}

bicluster_t *_creat_bicluster(uint id, bitmask_t * I, bitmask_t * L,
			      matrix_t * m, score_t score)
{
    bicluster_t *b = NULL;

    b = (bicluster_t *) safe_malloc(sizeof(bicluster_t));
    b->id = id;
    b->I = I;
    b->L = L;
    b->m = m;
    b->score = score;

    return b;
}

void bicluster_deep_destroy(bicluster_t * b)
{
    if (b == NULL)
	return;
    bitmask_destroy(b->I);
    bitmask_destroy(b->L);
    safe_free(b);
}

bicluster_t *bicluster_clone(bicluster_t * b)
{
    return _creat_bicluster(b->id, bitmask_clone(b->I),
			    bitmask_clone(b->L), b->m, b->score);
}

bicluster_t *creat_bicluster_from_seed(seed_t * s, matrix_t * m)
{
    return creat_bicluster(bitmask_clone(s->mask),
			   s->is_diag ? bitmask_clone(s->
						      mask) :
			   creat_bitmask(MERS(options.lambda)), m,
			   s->score);
}

bool_t bicluster_includes(bicluster_t * b, bicluster_t * t)
{
    return bitmask_includes(b->I, t->I) && bitmask_includes(b->L, t->L);
}

bool_t bicluster_is_constant(bicluster_t * b)
{
    score_t score = 0;
    motif_t m1 = 0, m2 = 0;

    if (b == NULL)
	return 0;

    for (m1 = 0; m1 < MERS(options.lambda); m1++) {
	for (m2 = 0; m2 <= m1; m2++) {
	    score = b->m->entries[m1][m2]->score;
	    if (m1 != m2) {
		if (bitmask_isset(b->I, m1) && bitmask_isset(b->I, m2)
		    && (score < b->score)) {
		    return 0;
		}
	    } else {
		if (bitmask_isset(b->L, m1) && (score < b->score))
		    return 0;
	    }
	}
    }

    return 1;
}

bicluster_t *bicluster_set_rc(bicluster_t * b, motif_t rc)
{
    b->I = bitmask_set(b->I, rc);
    return b;
}

bool_t bicluster_isset_rc(bicluster_t * b, motif_t rc)
{
    return bitmask_isset(b->I, rc);
}

bicluster_t *bicluster_set_diag(bicluster_t * b, motif_t diag)
{
#ifdef MUSA_DEBUG
    assert(bitmask_isset(b->I, diag));
#endif
    b->L = bitmask_set(b->L, diag);
    return b;
}

bool_t bicluster_isset_diag(bicluster_t * b, motif_t diag)
{
    return bitmask_isset(b->L, diag);
}


bicluster_t *bicluster_unset_rc(bicluster_t * b, motif_t rc)
{
#ifdef MUSA_DEBUG
    assert(!bitmask_isset(b->L, rc));
#endif
    b->I = bitmask_unset(b->I, rc);
    return b;
}

bicluster_t *bicluster_unset_diag(bicluster_t * b, motif_t diag)
{
    b->L = bitmask_unset(b->L, diag);
    return b;
}

uint bicluster_size(bicluster_t * b)
{
    uint i = 0;
    uint size = 0;

    for (i = 0; i < MERS(options.lambda); i++) {
	if (bitmask_isset(b->I, i))
	    size++;
    }

    return size;
}

void bicluster_print(bicluster_t * b)
{

    score_t score = 0;
    char *sm1 = NULL, *sm2 = NULL;
    int m1 = 0, m2 = 0;
    ilist_t *distances = NULL;
    iiterator_t *iter = NULL;

    if (b == NULL)
	return;

    message("Printing bicluster with score %d", b->score);
#ifdef MUSA_DEBUG
    assert(bicluster_is_constant(b));
#endif

    for (m1 = 0; m1 < MERS(options.lambda); m1++) {
	for (m2 = 0; m2 <= m1; m2++) {
	    score = b->m->entries[m1][m2]->score;
	    distances = b->m->entries[m1][m2]->distances;
	    if (m1 != m2) {
		if (bitmask_isset(b->I, m1) && bitmask_isset(b->I, m2)) {
		    sm1 = motif2str(m1);
		    sm2 = motif2str(m2);
		    iter = ilist_iterate_reset(distances);
		    while (ilist_iterate_has_next(iter)) {
			message("%d %s %d %s %d %d", b->id, sm1,
				ilist_iterate_next(iter), sm2, score,
				b->score);
		    }
		    ilist_iterate_finish(iter);
		    safe_free(sm1);
		    safe_free(sm2);
		}
	    } else {
		if (bitmask_isset(b->L, m1)) {
#ifdef MUSA_DEBUG
		    assert(bitmask_isset(b->I, m1));
#endif
		    sm1 = motif2str(m1);
		    iter = ilist_iterate_reset(distances);
		    while (ilist_iterate_has_next(iter)) {
			message("%d %s %d %s %d %d", b->id, sm1,
				ilist_iterate_next(iter), sm1, score,
				b->score);
		    }
		    ilist_iterate_finish(iter);

		    safe_free(sm1);
		}
	    }
	}
    }

    return;

}

void bicluster_dump(bicluster_t * b)
{
    message_l("BICLUSTER(id=%d,\n\tscore=%d\n\tI=", b->id, b->score);
    bitmask_dump(b->I);
    message_l("\n\tL=");
    bitmask_dump(b->L);
    message("\n\t)");
}
