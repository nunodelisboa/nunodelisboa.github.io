#include <stdio.h>
#include <stdlib.h>
#include <strings.h>
#include <string.h>

#include "sequences.h"
#include "util.h"
#include "debug.h"
#include "definitions.h"
#include "options.h"

#define BUFFERLEN 	5
#define SEQESTIMATE	100

extern options_t options;

dataset_t *parse_fasta(FILE * fasta)
{
    char buffer[BUFFERLEN];
    char c = '\0';
    uint seqn = 0, seqestimate = 0;
    char **sequences = NULL, **seqbuffer = NULL, *curseqbuffer = NULL;

    int i = 0, j = 0;
    uint state = 0;
    uint seenheader = 0;


    ssize_t read = 0, seqlen = 0, seqalloc = 0;

    bzero(buffer, BUFFERLEN);
    while ((read = fread(buffer, 1, BUFFERLEN - 1, fasta)) > 0) {
#ifdef MUSA_DEBUG
//      message("Read \n%s", buffer);
#endif
	i = 0;
	while ((c = buffer[i]) != '\0') {
	    switch (c) {
	    case '>':
		state = 1;
		seenheader = 1;
		if (seqn >= seqestimate) {

		    seqbuffer =
			(char **) safe_malloc(sizeof(char *) *
					      (seqn + SEQESTIMATE));
		    for (j = 0; j < seqn; j++)
			seqbuffer[j] = sequences[j];

		    for (j = seqn; j < seqn + SEQESTIMATE; j++)
			seqbuffer[j] = NULL;

		    if (seqestimate)
			safe_free(sequences);
		    sequences = seqbuffer;
		    seqestimate = seqn + SEQESTIMATE;
		}
		seqn++;
		seqlen = seqalloc = 0;
		break;
	    case '\n':
		if (state == 1)
		    state = 0;
		break;
	    case ' ':
		break;
	    default:
		if (state == 0) {
		    if (!seenheader)
			error("Invalid FASTA file");

		    if (seqlen + 1 >= seqalloc) {

			curseqbuffer =
			    (char *) safe_malloc(sizeof(char) *
						 (seqlen + BUFFERLEN));
			bzero(curseqbuffer, seqlen + BUFFERLEN);

			if (seqlen) {
			    strcpy(curseqbuffer, sequences[seqn - 1]);
			    safe_free(sequences[seqn - 1]);
			}
			sequences[seqn - 1] = curseqbuffer;

			seqalloc = seqlen + BUFFERLEN;
		    }

		    sequences[seqn - 1][seqlen++] = buffer[i];
#ifdef MUSA_DEBUG
//                  message("SEQ: %s", sequences[seqn - 1]);
#endif


		}
	    }
	    i++;
	}
	bzero(buffer, BUFFERLEN);
    }



    /* wrap up */
    seqbuffer = (char **) safe_malloc(sizeof(char *) * (seqn));

    for (j = 0; j < seqn; j++)
	seqbuffer[j] = sequences[j];

    safe_free(sequences);
    sequences = seqbuffer;

    for (i = 0; i < seqn; i++) {
	if (sequences[i] != NULL) {
	    seqlen = strlen(sequences[i]) + 1;

	    if (seqlen <= options.lambda) {
		safe_free(sequences[i]);
		sequences[i] = NULL;
	    } else {


		curseqbuffer =
		    (char *) safe_malloc(sizeof(char) * (seqlen));

		bzero(curseqbuffer, seqlen);

		if (seqlen) {
		    strcpy(curseqbuffer, sequences[i]);
		    safe_free(sequences[i]);
		}

		for (j = 0; j < strlen(curseqbuffer); j++) {
		    switch (curseqbuffer[j]) {
		    case 'A':
		    case 'T':
		    case 'G':
		    case 'C':
			break;

		    case 'a':
			curseqbuffer[j] = 'A';
			break;
		    case 't':
			curseqbuffer[j] = 'T';
			break;
		    case 'c':
			curseqbuffer[j] = 'C';
			break;
		    case 'g':
			curseqbuffer[j] = 'G';
			break;

		    default:
			message
			    ("Unknown nucleotide in sequence %d position %d",
			     i, j);
			break;
		    }

		}

		sequences[i] = curseqbuffer;

	    }
	}

    }

    fclose(fasta);
    return creat_dataset(seqn, sequences);
}
