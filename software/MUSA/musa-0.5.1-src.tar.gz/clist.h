#ifndef QLIST_H
#define QLIST_H

#include "list.h"
#include "configuration.h"

typedef list_t clist_t;
typedef iterator_t citerator_t;

clist_t *creat_clist();
void clist_destroy(clist_t *);
clist_t *clist_add_configuration(clist_t *, configuration_t *);
clist_t *clist_remove_configuration(clist_t *, configuration_t *);
configuration_t *clist_get(clist_t *, unsigned int);
configuration_t *clist_get_first(clist_t *);
configuration_t *clist_get_last(clist_t *);
citerator_t *clist_iterate_reset(clist_t *);
citerator_t *clist_iterate_rewind(clist_t *);
int clist_iterate_has_next(citerator_t *);
int clist_iterate_has_previous(citerator_t *);
configuration_t *clist_iterate_next(citerator_t *);
configuration_t *clist_iterate_previous(citerator_t *);
void clist_iterate_finish(citerator_t *);
uint clist_nconfigurations(clist_t *);

int configuration_compare(configuration_t *, configuration_t *);
int configuration_equal(configuration_t *, configuration_t *);
uint configuration_id(configuration_t *);


#endif
