/*

        Ranges

        by Nuno D. Mendes
	$Id: range.c,v 1.3 2007/03/02 16:40:25 nnmen Exp $


*/

#include "range.h"
#include "util.h"

range_t *creat_range(ushort min, ushort max)
{
    range_t *d = NULL;

    d = (range_t *) safe_malloc(sizeof(range_t));
    d->min = min;
    d->max = max;

    return d;
}

range_t *range_clone(range_t * d)
{
    return creat_range(d->min, d->max);
}

void range_destroy(range_t * d)
{
    if (d == NULL)
	return;
    safe_free(d);
}
