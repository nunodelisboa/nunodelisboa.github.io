/*

        List of range objects

        by Nuno D. Mendes
	$Id: rlist.c,v 1.3 2007/03/02 16:40:25 nnmen Exp $


*/

#include <stdlib.h>
#include <stdio.h>

#include "list.h"
#include "rlist.h"
#include "range.h"
#include "util.h"

rlist_t *creat_rlist()
{
    rlist_t *list = NULL;
    list = creat_list((int (*)(void *, void *)) range_compare,
		      (int (*)(void *, void *)) range_equal,
		      (unsigned int (*)(void *)) range_id);
    return list;
}

rlist_t *rlist_clone(rlist_t * l)
{
    rlist_t *nl = NULL;
    riterator_t *i = NULL;

    nl = creat_rlist();
    i = rlist_iterate_reset(l);
    while (rlist_iterate_has_next(i))
	rlist_add_range(nl, range_clone(rlist_iterate_next(i)));
    rlist_iterate_finish(i);

    return nl;
}

range_t *rlist_get_first(rlist_t * l)
{
    if (l == NULL)
	return NULL;
    return (range_t *) list_get_first(l);
}

void rlist_destroy(rlist_t * l)
{
    list_destroy(l);
}

void rlist_deep_destroy(rlist_t * l)
{
    riterator_t *i = NULL;

    i = rlist_iterate_reset(l);
    while (rlist_iterate_has_next(i))
	range_destroy(rlist_iterate_next(i));
    rlist_iterate_finish(i);
    rlist_destroy(l);

}

rlist_t *rlist_add_range(rlist_t * list, range_t * d)
{

    if (list == NULL)
	return list;
    list = list_add_elem_t(list, d);
    return list;

}

int rlist_nranges(rlist_t * list)
{
    if (list == NULL)
	return 0;
    return list_nelems(list);
}

riterator_t *rlist_iterate_reset(rlist_t * l)
{
    return list_iterate_reset(l);
}

riterator_t *rlist_iterate_rewind(rlist_t * l)
{
    return list_iterate_rewind(l);
}

int rlist_iterate_has_next(riterator_t * i)
{
    return list_iterate_has_next(i);
}

int rlist_iterate_has_previous(riterator_t * i)
{
    return list_iterate_has_previous(i);
}

range_t *rlist_iterate_next(riterator_t * i)
{
    return list_iterate_next(i);
}

range_t *rlist_iterate_previous(riterator_t * i)
{
    return list_iterate_previous(i);
}

void rlist_iterate_finish(riterator_t * i)
{
    list_iterate_finish(i);
}

int range_compare(range_t * r1, range_t * r2)
{
    return 0;
}

int range_equal(range_t * r1, range_t * r2)
{
    return 0;
}

int range_id(range_t * r)
{
    return 0;
}
