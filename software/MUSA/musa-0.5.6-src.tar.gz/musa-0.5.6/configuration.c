/*

        Functions for manipulation of configurations

        by Nuno D. Mendes
	$Id: configuration.c,v 1.13 2007/04/02 15:20:51 nnmen Exp $


*/

#include <stdlib.h>
#include <stdio.h>

#include "sequences.h"
#include "configuration.h"
#include "types.h"
#include "options.h"
#include "bitmask.h"
#include "debug.h"
#include "util.h"

extern options_t options;

delta_list_t *generate_delta_list(profile_t * p, motif_t m1, motif_t m2)
{

    delta_list_t *delta = NULL;
    ilist_t *mfpos1 = NULL, *mfpos2 = NULL;
    ilist_t *mrpos1 = NULL, *mrpos2 = NULL;
    iiterator_t *i1 = NULL, *i2 = NULL;
    int pos1 = 0, pos2 = 0;
    ilist_t *distances = NULL;
    int i = 0, k = 0;
    uint dd = 0;

    delta = (delta_list_t *) safe_malloc(sizeof(delta_list_t));
    delta->distances = (ilist_t **) safe_malloc(sizeof(void *) * p->seqn);

    for (i = 0; i < p->seqn; i++) {

	delta->distances[i] = NULL;

	mfpos1 = p->fpositions[i][m1];
	mfpos2 = p->fpositions[i][m2];
	if (options.bothstrands) {
	    mrpos1 = p->rpositions[i][m1];
	    mrpos2 = p->rpositions[i][m2];
	}

	if ((mfpos1 != NULL && mfpos2 != NULL)
	    || (mrpos1 != NULL && mrpos2 != NULL))
	    distances = creat_ilist(NO_REPETITION);
	else
	    distances = NULL;

	if (mfpos1 != NULL && mfpos2 != NULL) {

	    i1 = ilist_iterate_reset(mfpos1);
	    while (ilist_iterate_has_next(i1)) {
		pos1 = ilist_iterate_next(i1);
		i2 = ilist_iterate_reset(mfpos2);
		while (ilist_iterate_has_next(i2)) {
		    pos2 = ilist_iterate_next(i2);
		    dd = pos2 - pos1;
		    if (dd != 0 && abs(dd) <= options.maxdist
			&& abs(dd) >= options.mindist) {
			for (k = -options.epsilon; k <= options.epsilon;
			     k++) {
			    if (dd + k != 0
				&& abs(dd + k) <= options.maxdist
				&& abs(dd + k) >= options.mindist) {
				if (k == 0 || abs(dd) > options.lambda) {
				    ilist_add_int(distances, dd + k);
				}
			    }
			}
		    }
		}
		ilist_iterate_finish(i2);
	    }
	    ilist_iterate_finish(i1);
	}

	if (mrpos1 != NULL && mrpos2 != NULL) {

	    i1 = ilist_iterate_reset(mrpos1);
	    while (ilist_iterate_has_next(i1)) {
		pos1 = ilist_iterate_next(i1);
		i2 = ilist_iterate_reset(mrpos2);
		while (ilist_iterate_has_next(i2)) {
		    pos2 = ilist_iterate_next(i2);
		    dd = pos2 - pos1;
		    if (dd != 0 && abs(dd) <= options.maxdist
			&& abs(dd) >= options.mindist) {
			for (k = -options.epsilon; k <= options.epsilon;
			     k++) {
			    if (dd + k != 0
				&& abs(dd + k) <= options.maxdist
				&& abs(dd + k) >= options.mindist) {
				if (k == 0 || abs(dd) > options.lambda) {
				    ilist_add_int(distances, dd + k);
				}
			    }
			}
		    }
		}
		ilist_iterate_finish(i2);
	    }
	    ilist_iterate_finish(i1);
	}


	delta->distances[i] = distances;

    }

    return delta;
}

void destroy_delta_list(delta_list_t * d)
{
    int i = 0;

    if (d == NULL)
	return;

    for (i = 0; i < options.seqn; i++) {
	ilist_destroy(d->distances[i]);
    }
    safe_free(d->distances);
    safe_free(d);
}

configuration_t *creat_configuration(motif_t motif1, motif_t motif2,
				     distance_t distance, score_t score)
{
    static uint id = 0;

    configuration_t *c = NULL;
    c = (configuration_t *) safe_malloc(sizeof(configuration_t));

    c->id = ++id;
    c->motif1 = motif1;
    c->motif2 = motif2;
    c->distance = distance;
    c->score = score;

    return c;
}

void destroy_configuration(configuration_t * c)
{
    if (c != NULL)
	safe_free(c);
}
