/*

        List of occurrences in a given sequence

        by Nuno D. Mendes
	$Id: occseq.c,v 1.4 2007/03/02 16:40:25 nnmen Exp $


*/

#include "occseq.h"
#include "util.h"
#include "ilist.h"

occseq_t *creat_occseq(ushort seqn)
{
    occseq_t *oc = NULL;

    oc = (occseq_t *) safe_malloc(sizeof(occseq_t));
    oc->seqn = seqn;
    oc->pos_forward = creat_ilist(NO_REPETITION);
    oc->pos_reverse = creat_ilist(NO_REPETITION);

    return oc;
}

occseq_t *occseq_clone(occseq_t * oc)
{
    occseq_t *noc = NULL;

    noc = (occseq_t *) safe_malloc(sizeof(occseq_t));
    noc->seqn = oc->seqn;
    noc->pos_forward = ilist_clone(oc->pos_forward);
    noc->pos_reverse = ilist_clone(oc->pos_reverse);
    return noc;
}

occseq_t *occseq_add_pos(occseq_t * oc, uint pos, occ_direction_t dir)
{
    if (oc == NULL)
	return NULL;
    if (dir == FORWARD_STRAND)
	ilist_add_int(oc->pos_forward, pos);
    else
	ilist_add_int(oc->pos_reverse, pos);

    return oc;

}

ilist_t *occseq_poslist(occseq_t * oc, occ_direction_t dir)
{
    if (oc == NULL)
	return NULL;
    return dir == FORWARD_STRAND ? oc->pos_forward : oc->pos_reverse;
}

void destroy_occseq(occseq_t * oc)
{
    if (oc == NULL)
	return;
    ilist_destroy(oc->pos_forward);
    ilist_destroy(oc->pos_reverse);
    safe_free(oc);
}
