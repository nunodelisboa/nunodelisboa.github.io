#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#ifdef __GLIBC__
#include <argp.h>
#else
#include "argp.h"
#endif

#include "fasta.h"
#include "sequences.h"
#include "definitions.h"
#include "types.h"
#include "configuration.h"
#include "matrix.h"
#include "slist.h"
#include "blist.h"
#include "mrlist.h"
#include "biclustering.h"
#include "matcher.h"
#include "musa_matcher.h"
#include "motif_report.h"
#include "musa_motif_report.h"
#include "options.h"
#include "bitmask.h"
#include "debug.h"
#include "stat.h"
#include "util.h"

options_t options;

const char *argp_program_version = "musa 0.5.6";
const char *argp_program_bug_address = "<ndm+musa_bugs@algos.inesc-id.pt>";

static char doc[] = "MUSA -- Inference of Complex Motifs";

static char args_doc[] = "FASTA|-";

static struct argp_option opt[] = {
    {"quiet", 'q', 0, 0, "Behave quietly"},
    {"output", 'o', "FILE", 0,
     "Output to FILE instead of standard output"},
    {"lambda", 'l', "LAMBDA", 0, "Lambda parameter (size of lambda-mers)"},
    {"epsilon", 'e', "EPSILON", 0,
     "Epsilon parameter (distance tolerance)"},
    {"sieve", 's', "SIEVE", 0, "Percent of minimum number of sequences"},
    {"mindist", 'm', "mindist", 0, "Minimum distance between lambda-mers"},
    {"maxdist", 'M', "maxdist", 0, "Maximum distance between lambda-mers"},
    {"bothstrands", 'b', 0, 0, "Search both strands"},
    {0}
};

struct arguments {
    char *input;
    bool_t quiet;
    bool_t bothstrands;
    char *output_file;
    ushort lambda;
    ushort epsilon;
    ushort sieverate;
    uint mindist;
    uint maxdist;
};


static error_t parse_opt(int key, char *arg, struct argp_state *state)
{
    struct arguments *arguments = state->input;

    switch (key) {
    case 'q':
	arguments->quiet = 1;
	break;
    case 'b':
	arguments->bothstrands = 1;
	break;
    case 'o':
	arguments->output_file = arg;
	break;
    case 'l':
	arguments->lambda = atoi(arg);
	break;
    case 'e':
	arguments->epsilon = atoi(arg);
	break;
    case 's':
	arguments->sieverate = atoi(arg);
	break;
    case 'm':
	arguments->mindist = atoi(arg);
	break;
    case 'M':
	arguments->maxdist = atoi(arg);
    case ARGP_KEY_ARG:
	if (state->arg_num > 1)
	    argp_usage(state);

	arguments->input = arg;
	break;

    case ARGP_KEY_END:
	if (state->arg_num < 1)
	    argp_usage(state);
	break;

    default:
	return ARGP_ERR_UNKNOWN;

    }

    return 0;
}

static struct argp argp = { opt, parse_opt, args_doc, doc };

#ifdef MUSA_DEBUG
void test()
{
    test_bitmask();
}
#endif

int main(int argc, char **argv)
{
    dataset_t *ds = NULL;
    profile_t *p = NULL;
    matrix_t *m = NULL;
    slist_t *s = NULL;
    blist_t *b = NULL;
    mrlist_t *mr = NULL, *report = NULL;
    mriterator_t *mi = NULL;
    FILE *input = NULL;
    stat_model_t *model = NULL;

    struct arguments arguments;

#ifdef MUSA_DEBUG
    test();
#endif

    arguments.quiet = 0;
    arguments.bothstrands = 0;
    arguments.output_file = NULL;
    arguments.input = "-";
    arguments.sieverate = DEFAULT_SIEVERATE;
    arguments.lambda = DEFAULT_LAMBDA;
    arguments.epsilon = DEFAULT_EPSILON;
    arguments.mindist = DEFAULT_MINDIST;
    arguments.maxdist = DEFAULT_MAXDIST;

    argp_parse(&argp, argc, argv, 0, 0, &arguments);

    options.quiet = arguments.quiet;
    options.bothstrands = arguments.bothstrands;
    options.lambda = arguments.lambda;
    options.epsilon = arguments.epsilon;
    options.sieverate = arguments.sieverate;
    options.mindist = arguments.mindist >= 1 ? arguments.mindist : 1;
    options.maxdist = arguments.maxdist;
    if (arguments.output_file == NULL) {
	options.output_file = stdout;
    } else {
	options.output_file = safe_fopen(arguments.output_file, "w");
    }

    if (arguments.input[0] == '-') {
	input = stdin;
    } else {
	input = safe_fopen(arguments.input, "r");
    }


    ds = parse_fasta(input);
    options.seqn = ds->seqn;
    options.sieve = (options.seqn * options.sieverate) / 100;
    if ((options.seqn * options.sieverate) % 100)
	options.sieve++;
    options.sieve = options.sieve ? options.sieve : 1;

    message("Generating profile with lambda = %d", options.lambda);

    p = generate_profile(ds);

    message("Generating matrix");
    m = generate_matrix(p);
    destroy_profile(p);

    message("Done.");
    message("Destroyed profile");

    message("Generating seeds");

    s = generate_seeds(m, options.sieve);
    message("Done");

    message("Generating biclusters");
    b = extract_biclusters(m, s);
    message("\nGenerated %d biclusters", blist_nbiclusters(b));
    message("Done.");
    destroy_seeds(s);
    message("Destroyed seed list.");

    mr = generate_mrlist(b);
    blist_deep_destroy(b);
    message("Destroyed list of biclusters");

    destroy_matrix(m);
    message("Destroyed matrix");

    mr = match(mr, ds, options.bothstrands);
    mr = filter(mr);

    message("Building Markov model");
    model = stat_model(ds);
    message("Evaluating...");
    mr = stat_evaluate(mr, model, options.bothstrands);
    destroy_stat_model(model);
    message("Destroyed Markov model");

    report = creat_mrlist();
    mi = mrlist_iterate_reset(mr);
    while (mrlist_iterate_has_next(mi))
	mrlist_add_motif_report(report, mrlist_iterate_next(mi));

    mrlist_iterate_finish(mi);

    mrlist_destroy(mr);

/*********** Print motif list ****************/

    mi = mrlist_iterate_reset(report);
    fprintf(options.output_file, "# MUSA/0.5.6 Output\n");
    fprintf(options.output_file, "# Sequences: %d Motifs: %d\n",
	    options.seqn, mrlist_nmotif_reports(report));
    fprintf(options.output_file, "%-30s\t%-10s\tP-value\n", "# Motif",
	    "Quorum");
    while (mrlist_iterate_has_next(mi))
	print_motif_report(mrlist_iterate_next(mi));
    mrlist_iterate_finish(mi);

    destroy_dataset(ds);
    message("Destroyed dataset");

    mi = mrlist_iterate_reset(report);
    while (mrlist_iterate_has_next(mi))
	destroy_motif_report(mrlist_iterate_next(mi));
    mrlist_iterate_finish(mi);

    /** ====> Further processing of mrlist here <==== **/


    mrlist_destroy(report);


    message("Done.");

    if (arguments.output_file != NULL)
	fclose(options.output_file);



    return 0;
}
