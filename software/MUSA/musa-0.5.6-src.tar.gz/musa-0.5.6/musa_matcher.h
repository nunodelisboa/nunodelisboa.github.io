#ifndef MUSA_MATCHER_H
#define MUSA_MATCHER_H

#include "mrlist.h"

mrlist_t *filter(mrlist_t *);


#endif
