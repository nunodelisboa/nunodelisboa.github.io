/*

        Graph fuctions

        by Nuno D. Mendes
	$Id: graph.c,v 1.13 2007/04/03 11:39:12 nnmen Exp $


*/

#include <stdio.h>
#include <stdlib.h>
#include <strings.h>
#include <string.h>

#include "graph.h"
#include "options.h"
#include "util.h"
#include "debug.h"
#include "types.h"

extern options_t options;

graph_t *graph_creat()
{
    graph_t *g = NULL;

    g = (graph_t *) safe_malloc(sizeof(graph_t));
    g->head = NULL;
    g->color = 0;
    g->nnodes = 0;
    g->nself_loops = 0;

    return g;
}

gnode_t *gnode_creat(motif_t id)
{
    gnode_t *n = NULL;

    n = (gnode_t *) safe_malloc(sizeof(gnode_t));

    n->id = id;
    n->inbound = 0;
    n->outbound = 0;
    n->color = 0;
    n->short_range = NULL;
    n->long_range = NULL;
    n->self_loop = NULL;
    n->next = NULL;

    return n;
}

link_t *link_creat(score_t score, uint distance, gnode_t * n)
{
    link_t *l = NULL;

    l = (link_t *) safe_malloc(sizeof(link_t));

    l->score = score;
    l->distance = distance;
    l->target = n;
    l->next = NULL;

    return l;
}

graph_t *graph_add_configuration(graph_t * g, configuration_t * c)
{
    char *motif1 = NULL, *motif2 = NULL;
    motif1 = motif2str(c->motif1);
    motif2 = motif2str(c->motif2);

#if MUSA_DEBGU
    message("Adding configuration <%s>-(%d)-<%s>", motif1,
	    c->distance, motif2);
#endif


    if (!graph_has_node_id(g, c->motif1)) {
#if MUSA_DEBUG
	message("Adding gnode for %s", motif1);
#endif
	graph_add_node(g, c->motif1);
    }

    if (!graph_has_node_id(g, c->motif2)) {
#if MUSA_DEBUG
	message("Adding gnode for %s", motif2);
#endif
	graph_add_node(g, c->motif2);
    }
#if MUSA_DEBUG
    message("Adding link");
#endif
    if (c->distance > 0)
	graph_add_link(g, c->motif1, c->motif2, c->distance, c->score);
    else
	graph_add_link(g, c->motif2, c->motif1, -c->distance, c->score);

    safe_free(motif1);
    safe_free(motif2);

    return g;
}

bool_t graph_has_node_id(graph_t * g, motif_t id)
{
    gnode_t *n = NULL;

    if (g->head == NULL)
	return 0;

    n = g->head;
    while (n != NULL) {
	if (n->id == id)
	    return 1;
	n = n->next;
    }

    return 0;
}

graph_t *graph_add_node(graph_t * g, motif_t id)
{

    gnode_t *n = NULL;

    n = gnode_creat(id);
    n->next = g->head;
    g->head = n;
    g->nnodes++;

    return g;
}

graph_t *graph_add_link(graph_t * g, motif_t m1, motif_t m2, uint distance,
			score_t score)
{

    gnode_t *g1 = NULL, *g2 = NULL, *aux = NULL;
    link_t *l = NULL;

    aux = g->head;

    while (aux != NULL && (g1 == NULL || g2 == NULL)) {
	if (aux->id == m1)
	    g1 = aux;
	if (aux->id == m2)
	    g2 = aux;
	aux = aux->next;
    }

    if (g1 == NULL || g2 == NULL) {
#if MUSA_DEBUG
	warn("Could not add link");
#endif
	return g;
    }

    l = link_creat(score, distance, g2);

    if (m1 == m2) {
#if MUSA_DEBUG
	message("Adding self loop link");
#endif
	g->nself_loops++;
	l->next = g1->self_loop;
	g1->self_loop = l;
    } else if (distance <= options.lambda) {
#if MUSA_DEBUG
	message("Adding short range link");
#endif
	l->next = g1->short_range;
	g1->short_range = l;
	g1->outbound++;
	g2->inbound++;
    } else {
#if MUSA_DEBUG
	message("Adding long range link");
#endif
	l->next = g1->long_range;
	g1->long_range = l;
	g1->outbound++;
	g2->inbound++;
    }

    return g;

}

char *graph2motif(graph_t * g)
{
    gnode_t *n = NULL;
    gnode_t *min = NULL;
    link_t *l = NULL, *lmin = NULL;
    char *motif = NULL;
    char *buffer = NULL, *res = NULL;
    int lmercount = 0, justfollowed = 0, nboxes = 1, lastdistance = 0;
    int minscore = 0, i = 0;
    uint buffersize = 0, bp = 0;

    g->color++;
    n = g->head;

    buffersize =
	((g->nnodes + g->nself_loops) * options.lambda +
	 (g->nnodes + g->nself_loops - 1) * (1 + 4 + 1));
    buffer = (char *) safe_malloc((buffersize + 1) * sizeof(char));
    for (i = 0; i <= buffersize; i++)
	buffer[i] = '\0';

    while (n != NULL) {
	if (min == NULL || (!min->outbound && n->outbound))
	    min = n;
	if (n->inbound < min->inbound && n->outbound) {
	    min = n;
	}
	n = n->next;
    }

    n = min;

    while (n != NULL && n->color != g->color) {
	motif = motif2str(n->id);
	if (lmercount++ == 0) {
#if MUSA_DEBUG
	    message("Inaugurating buffer with %s", motif);
#endif
	    bp += sprintf(buffer + bp, "%s", motif);
#if MUSA_DEBUG
	    message("buffer = %s", buffer);
#endif
	} else {
	    if (justfollowed == 1) {
#if MUSA_DEBUG
		message("Adding overlapping motif: %s", motif);
#endif
		bp += sprintf(buffer + bp, "%s",
			      motif + options.lambda - lastdistance);
#if MUSA_DEBUG
		message("buffer = %s", buffer);
#endif
	    } else if (justfollowed == 2) {
#if MUSA_DEBUG
		message("Adding detached motif: %s", motif);
#endif
		bp +=
		    sprintf(buffer + bp, " %d %s",
			    lastdistance - options.lambda, motif);
#if MUSA_DEBUG
		message("buffer = %s", buffer);
#endif
		nboxes++;
	    } else if (justfollowed == 3 && bp == 4) {
		// ignores long distance self loops, should it?
		// is very conservative in adding self loops
#if MUSA_DEBUG
		message("Adding overlapping self loop motif: %s", motif);
#endif
		if (lastdistance <= options.lambda) {
		    bp +=
			sprintf(buffer + bp, "%s",
				motif + options.lambda - lastdistance);
		} else {

		    bp +=
			sprintf(buffer + bp, " %d %s",
				lastdistance - options.lambda, motif);
		}
#if MUSA_DEBUG
		message("buffer = %s", buffer);
#endif
	    }
	}
	safe_free(motif);

	lmin = NULL;
	if (n->short_range != NULL) {
	    l = n->short_range;
	    justfollowed = 1;
	} else if (n->long_range != NULL) {
	    l = n->long_range;
	    justfollowed = 2;
	} else {
	    if (n->self_loop != NULL && justfollowed != 3) {
		l = n->self_loop;
		justfollowed = 3;
	    }
	}

	if (justfollowed != 3)
	    n->color = g->color;

//      message("Just Followed Code = %d", justfollowed);

	while (l != NULL) {
	    if (lmin == NULL)
		lmin = l;
	    if (l->distance < lmin->distance)
		lmin = l;
	    l = l->next;
	}

	if (lmin != NULL) {
	    lastdistance = lmin->distance;
	    if (minscore == 0)
		minscore = lmin->score;
	    if (minscore < lmin->score)
		minscore = lmin->score;
	    n = lmin->target;
	} else {
	    n = NULL;
//          message("motif concluded");
	}
    }
    //fprintf(stdout, " % d % d % s \ n ", minscore, nboxes, buffer);
    //fprintf(options.output_file, " % d % s \ n ", nboxes, buffer);
    //safe_free(buffer);

    res = (char *) safe_malloc(sizeof(char) * (strlen(buffer) + 4));
    bzero(res, strlen(buffer) + 4);
    //fprintf(stdout, " % d % s \ n ", nboxes, buffer);
    sprintf(res, "%d %s", nboxes, buffer);
    safe_free(buffer);
    return res;
}

void graph_destroy(graph_t * g)
{
    gnode_t *gnode = NULL, *prev = NULL;

    if (g == NULL)
	return;

    gnode = g->head;
    while (gnode != NULL) {
	prev = gnode;
	gnode = gnode->next;
	gnode_destroy(prev);
    }
    safe_free(g);
}

void gnode_destroy(gnode_t * node)
{
    link_t *link = NULL, *prev = NULL;

    if (node == NULL)
	return;

    link = node->self_loop;
    while (link != NULL) {
	prev = link;
	link = link->next;
	link_destroy(prev);
    }
    link = node->short_range;
    while (link != NULL) {
	prev = link;
	link = link->next;
	link_destroy(prev);
    }
    link = node->long_range;
    while (link != NULL) {
	prev = link;
	link = link->next;
	link_destroy(prev);
    }
    safe_free(node);
}

void link_destroy(link_t * l)
{
    if (l == NULL)
	return;
    safe_free(l);
}
