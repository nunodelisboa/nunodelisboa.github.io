/*

        Headers for cmotif.h

        by Nuno D. Mendes
	$Id: cmotif.h,v 1.4 2007/03/02 16:40:25 nnmen Exp $


*/


#ifndef CMOTIF_H
#define CMOTIF_H

#include "smotif.h"
#include "smlist.h"
#include "rlist.h"
#include "types.h"

typedef struct cmotif_str {
    smlist_t *boxes;		// a list of N simple motifs
    rlist_t *ranges;		// a list of N-1 ranges (min,max)
} cmotif_t;

cmotif_t *creat_cmotif(smotif_t *);
cmotif_t *cmotif_add_box(cmotif_t *, smotif_t *, ushort, ushort);
uint cmotif_nboxes(cmotif_t *);
void destroy_cmotif(cmotif_t *);


#endif
