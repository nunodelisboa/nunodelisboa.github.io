/*

        Memory manipultion wrappers
	(and integer power function)

        by Nuno D. Mendes
	$Id: util.c,v 1.6 2007/03/02 16:40:26 nnmen Exp $


*/

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "debug.h"

void *safe_malloc(size_t size)
{
    void *mem = NULL;

    if (size == 0)
	warn("Allocating 0 bytes!");

    if ((mem = malloc(size)) != NULL) {
	return mem;
    } else {
	error("Memory allocation error");
	return NULL;
    }
}

void *safe_calloc(size_t nmemb, size_t size)
{
    void *mem = NULL;

    if (size == 0 || nmemb == 0)
	warn("Allocating 0 bytes!");

    if ((mem = calloc(nmemb, size)) != NULL) {
	return mem;
    } else {
	error("Memory allocation error");
	return NULL;
    }

}

void safe_free(void *mem)
{
    if (mem != NULL)
	free(mem);
}

int ipow(int b, int e)
{
    return (int) pow((double) b, (double) e);
}

FILE *safe_fopen(const char *path, const char *mode)
{
    FILE *file = NULL;
    file = fopen(path, mode);
    if (file == NULL)
	error("Could not open file: %s\n", path);
    return file;
}
