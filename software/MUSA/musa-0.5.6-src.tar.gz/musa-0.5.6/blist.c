#include <stdlib.h>
#include <stdio.h>

#include "list.h"
#include "blist.h"
#include "util.h"

blist_t *creat_blist()
{
    blist_t *list = NULL;
    list = creat_list((int (*)(void *, void *)) bicluster_compare,
		      (int (*)(void *, void *)) bicluster_equal,
		      (uint(*)(void *)) bicluster_id);

    return list;
}

blist_t *blist_clone(blist_t * l)
{
    blist_t *nl = NULL;
    biterator_t *i = NULL;

    nl = creat_blist();
    i = blist_iterate_reset(l);
    while (blist_iterate_has_next(i))
	blist_add_bicluster(nl, blist_iterate_next(i));
    blist_iterate_finish(i);

    return nl;
}

bicluster_t *blist_get_first(blist_t * l)
{
    if (l == NULL)
	return NULL;
    return (bicluster_t *) list_get_first(l);
}

bicluster_t *blist_get_last(blist_t * l)
{
    if (l == NULL)
	return NULL;
    return (bicluster_t *) list_get_last(l);
}

bicluster_t *blist_get(blist_t * l, uint id)
{
    if (l == NULL)
	return NULL;
    return (bicluster_t *) list_get(l, id);
}

void blist_destroy(blist_t * l)
{
    list_destroy(l);
}

void blist_deep_destroy(blist_t * l)
{
    biterator_t *i = NULL;
    if (l == NULL)
	return;
    i = blist_iterate_reset(l);
    while (blist_iterate_has_next(i)) {
	bicluster_deep_destroy(blist_iterate_next(i));
    }
    blist_iterate_finish(i);
    blist_destroy(l);
}

blist_t *blist_add_bicluster(blist_t * list, bicluster_t * s)
{

    if (list == NULL)
	return list;
    list = list_add_elem_t(list, (void *) s);
    return list;

}

blist_t *blist_remove_bicluster(blist_t * list, bicluster_t * s)
{

    if (list == NULL)
	return list;
    list = list_remove_elem(list, (void *) s);
    return list;

}

uint blist_nbiclusters(blist_t * list)
{
    if (list == NULL)
	return 0;
    return list_nelems(list);
}

biterator_t *blist_iterate_reset(blist_t * l)
{
    return list_iterate_reset(l);
}

biterator_t *blist_iterate_rewind(blist_t * l)
{
    return list_iterate_rewind(l);
}

bool_t blist_iterate_has_next(biterator_t * i)
{
    return list_iterate_has_next(i);
}

bool_t blist_iterate_has_previous(biterator_t * i)
{
    return list_iterate_has_previous(i);
}

bicluster_t *blist_iterate_next(biterator_t * i)
{
    return (bicluster_t *) list_iterate_next(i);
}

bicluster_t *blist_iterate_previous(biterator_t * i)
{
    return (bicluster_t *) list_iterate_previous(i);
}

void blist_iterate_finish(biterator_t * i)
{
    list_iterate_finish(i);
}

int bicluster_compare(bicluster_t * s1, bicluster_t * s2)
{
    return s1->score < s2->score ? 1 : (s1->score == s2->score ? 0 : -1);
}

bool_t bicluster_equal(bicluster_t * s1, bicluster_t * s2)
{
    /* lists disallow equal elements, this way we circumvent this problem */
    return 0;
}

score_t bicluster_id(bicluster_t * s)
{
    return s->score;
}
