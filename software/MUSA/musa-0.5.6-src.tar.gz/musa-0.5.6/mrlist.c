/*

        List of motif reports

        by Nuno D. Mendes
	$Id: mrlist.c,v 1.6 2007/04/16 15:13:13 nnmen Exp $


*/

#include <stdlib.h>
#include <stdio.h>

#include "motif_report.h"
#include "mrlist.h"
#include "util.h"

int motif_report_compare(motif_report_t *, motif_report_t *);
int motif_report_equal(motif_report_t *, motif_report_t *);

mrlist_t *creat_mrlist()
{
    return (mrlist_t *) creat_list((int (*)(void *, void *))
				   motif_report_compare,
				   (int (*)(void *, void *))
				   motif_report_equal,
				   (unsigned int (*)(void *))
				   motif_report_id);
}

void mrlist_destroy(mrlist_t * l)
{
    list_destroy(l);
}

unsigned int mrlist_nmotif_reports(mrlist_t * l)
{
    return list_nelems((list_t *) l);
}


mrlist_t *mrlist_add_motif_report(mrlist_t * l, motif_report_t * mr)
{
    return list_add_elem(l, mr);
}

mrlist_t *mrlist_remove_motif_report(mrlist_t * l, motif_report_t * mr)
{
    return list_remove_elem(l, mr);
}

motif_report_t *mrlist_get(mrlist_t * l, unsigned int id)
{
    return list_get(l, id);
}

motif_report_t *mrlist_get_last(mrlist_t * l)
{
    return list_get_last(l);
}

int motif_report_compare(motif_report_t * mr1, motif_report_t * mr2)
{
    return mr1->pvalue < mr2->pvalue ? -1 : (mr1->pvalue ==
					     mr2->pvalue ? 0 : 1);
}

int motif_report_equal(motif_report_t * mr1, motif_report_t * mr2)
{
    return 0;
}

mriterator_t *mrlist_iterate_reset(mrlist_t * l)
{
    return list_iterate_reset(l);
}

int mrlist_iterate_has_next(mriterator_t * i)
{
    return list_iterate_has_next(i);
}

motif_report_t *mrlist_iterate_next(mriterator_t * i)
{
    return (motif_report_t *) list_iterate_next(i);
}

void mrlist_iterate_finish(mriterator_t * i)
{
    list_iterate_finish(i);
}
