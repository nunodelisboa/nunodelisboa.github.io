/*

        Headers for olist.c

        by Nuno D. Mendes
	$Id: olist.h,v 1.3 2007/03/02 16:40:25 nnmen Exp $


*/

#ifndef OLIST_H
#define OLIST_H

#include "list.h"
#include "occseq.h"

typedef list_t olist_t;
typedef iterator_t oiterator_t;

olist_t *creat_olist();
void olist_destroy(olist_t *);
void olist_deep_destroy(olist_t *);
olist_t *olist_add_occseq(olist_t *, occseq_t *);
occseq_t *olist_get_first(olist_t *);
occseq_t *olist_get_last(olist_t *);
oiterator_t *olist_iterate_reset(olist_t *);
oiterator_t *olist_iterate_rewind(olist_t *);
int olist_iterate_has_next(oiterator_t *);
int olist_iterate_has_previous(oiterator_t *);
occseq_t *olist_iterate_next(oiterator_t *);
occseq_t *olist_iterate_previous(oiterator_t *);
void olist_iterate_finish(oiterator_t *);
uint olist_noccseqs(olist_t *);
int occseq_compare(occseq_t *, occseq_t *);
int occseq_equal(occseq_t *, occseq_t *);
int occseq_id(occseq_t *);



#endif
