/*

        Headers for smotif.c

        by Nuno D. Mendes
	$Id: smotif.h,v 1.3 2007/03/02 16:40:26 nnmen Exp $


*/

#ifndef SMOTIF_H
#define SMOTIF_H

#include "types.h"

typedef struct smotif_str {
    char *word;
    ushort deg;
} smotif_t;

smotif_t *creat_smotif(char *, ushort);
void destroy_smotif(smotif_t *);


#endif
