/*

        Headers for ilist.c

        by Nuno D. Mendes
	$Id: ilist.h,v 1.5 2007/03/02 16:40:25 nnmen Exp $


*/

#ifndef LLIST_H
#define LLIST_H

#include "list.h"
#include "types.h"

#define WITH_REPETITION 1
#define NO_REPETITION 0

typedef list_t ilist_t;
typedef iterator_t iiterator_t;

ilist_t *creat_ilist(bool_t);
ilist_t *ilist_clone(ilist_t *);
void ilist_destroy(ilist_t *);
ilist_t *ilist_add_int(ilist_t *, int);
int ilist_get_first(ilist_t *);
int ilist_get_last(ilist_t *);
int ilist_get(ilist_t *, uint);
ilist_t *ilist_remove_int(ilist_t *, int);
int ilist_nints(ilist_t *);

iiterator_t *ilist_iterate_reset(ilist_t *);
iiterator_t *ilist_iterate_rewind(ilist_t *);
int ilist_iterate_has_next(iiterator_t *);
int ilist_iterate_has_previous(iiterator_t *);
int ilist_iterate_next(iiterator_t *);
int ilist_iterate_previous(iiterator_t *);
void ilist_iterate_finish(iiterator_t *);

int int_compare(int, int);
int int_equal(int, int);
int int_equal_norepetition(int, int);
int int_id(int);

#endif
