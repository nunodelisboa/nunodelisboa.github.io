/*

        Headers for buflist.c

        by Nuno D. Mendes
	$Id: buflist.h,v 1.4 2007/03/02 16:40:25 nnmen Exp $


*/

#ifndef BUFLIST_H
#define BUFLIST_H

#include "list.h"
#include "types.h"

#define WITH_REPETITION 1
#define NO_REPETITION 0

typedef list_t buflist_t;
typedef iterator_t bufiterator_t;

buflist_t *creat_buflist(bool_t);
buflist_t *buflist_clone(buflist_t *);
void buflist_destroy(buflist_t *);
buflist_t *buflist_add_buffer(buflist_t *, char *);
char *buflist_get_first(buflist_t *);
char *buflist_get_last(buflist_t *);
int buflist_nbuffers(buflist_t *);

bufiterator_t *buflist_iterate_reset(buflist_t *);
bufiterator_t *buflist_iterate_rewind(buflist_t *);
int buflist_iterate_has_next(bufiterator_t *);
int buflist_iterate_has_previous(bufiterator_t *);
char *buflist_iterate_next(bufiterator_t *);
char *buflist_iterate_previous(bufiterator_t *);
void buflist_iterate_finish(bufiterator_t *);

int buffer_compare(char *, char *);
int buffer_equal(char *, char *);
int buffer_equal_norepetition(char *, char *);
int buffer_id(char *);

#endif
