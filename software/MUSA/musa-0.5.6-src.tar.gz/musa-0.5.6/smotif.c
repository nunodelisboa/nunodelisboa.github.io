/*

        Simple motifs

        by Nuno D. Mendes
	$Id: smotif.c,v 1.4 2007/03/02 16:40:26 nnmen Exp $


*/

#include <string.h>

#include "smotif.h"
#include "util.h"

smotif_t *creat_smotif(char *word, ushort deg)
{
    smotif_t *sm = NULL;

    sm = (smotif_t *) safe_malloc(sizeof(smotif_t));
    sm->word = (char *) safe_malloc(sizeof(char) * (strlen(word) + 1));
    strcpy(sm->word, word);
    sm->deg = deg;

    return sm;
}

void destroy_smotif(smotif_t * sm)
{
    if (sm == NULL)
	return;
    safe_free(sm->word);
    safe_free(sm);
}
