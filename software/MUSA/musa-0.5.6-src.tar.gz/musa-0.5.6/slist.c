#include <stdlib.h>
#include <stdio.h>

#include "list.h"
#include "slist.h"
#include "util.h"

slist_t *creat_slist()
{
    slist_t *list = NULL;
    list = creat_list((int (*)(void *, void *)) seed_compare,
		      (int (*)(void *, void *)) seed_equal,
		      (unsigned int (*)(void *)) seed_id);

    return list;
}

slist_t *slist_clone(slist_t * l)
{
    slist_t *nl = NULL;
    siterator_t *i = NULL;

    nl = creat_slist();
    i = slist_iterate_reset(l);
    while (slist_iterate_has_next(i))
	slist_add_seed(nl, slist_iterate_next(i));
    slist_iterate_finish(i);

    return nl;
}

seed_t *slist_get_first(slist_t * l)
{
    if (l == NULL)
	return NULL;
    return (seed_t *) list_get_first(l);
}

seed_t *slist_get(slist_t * l, unsigned int id)
{
    if (l == NULL)
	return NULL;
    return (seed_t *) list_get(l, id);
}

void slist_destroy(slist_t * l)
{
    list_destroy(l);
}

slist_t *slist_add_seed(slist_t * list, seed_t * s)
{

    if (list == NULL)
	return list;
    list = list_add_elem_h(list, (void *) s);
    return list;

}

slist_t *slist_remove_seed(slist_t * list, seed_t * s)
{

    if (list == NULL)
	return list;
    list = list_remove_elem(list, (void *) s);
    return list;

}

uint slist_nseeds(slist_t * list)
{
    if (list == NULL)
	return 0;
    return list_nelems(list);
}

siterator_t *slist_iterate_reset(slist_t * l)
{
    return list_iterate_reset(l);
}

siterator_t *slist_iterate_rewind(slist_t * l)
{
    return list_iterate_rewind(l);
}

int slist_iterate_has_next(siterator_t * i)
{
    return list_iterate_has_next(i);
}

int slist_iterate_has_previous(siterator_t * i)
{
    return list_iterate_has_previous(i);
}

seed_t *slist_iterate_next(siterator_t * i)
{
    return (seed_t *) list_iterate_next(i);
}

seed_t *slist_iterate_previous(siterator_t * i)
{
    return (seed_t *) list_iterate_previous(i);
}

void slist_iterate_finish(siterator_t * i)
{
    list_iterate_finish(i);
}

int seed_compare(seed_t * s1, seed_t * s2)
{
    return s1->score < s2->score ? 1 : (s1->score == s2->score ? 0 : -1);
}

int seed_equal(seed_t * s1, seed_t * s2)
{
    /* lists disallow equal elements, this way we circumvent this problem */
    return 0;
}

score_t seed_id(seed_t * s)
{
    return s->score;
}
