/*

        Headers for util.c

        by Nuno D. Mendes
	$Id: util.h,v 1.9 2007/03/02 16:40:26 nnmen Exp $


*/


#ifndef UTILS_H
#define UTILS_H

#include <stdlib.h>
#include <stdio.h>

void *safe_malloc(size_t);
void *safe_calloc(size_t, size_t);
void safe_free(void *);
int ipow(int, int);
FILE *safe_fopen(const char *, const char *);


#endif
