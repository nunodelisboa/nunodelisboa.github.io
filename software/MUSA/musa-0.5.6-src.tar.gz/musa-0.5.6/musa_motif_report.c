#include "motif_report.h"
#include "options.h"

extern options_t options;

void print_motif_report(motif_report_t * mr)
{
    smiterator_t *i = NULL;
    riterator_t *ri = NULL;
    smotif_t *sm = NULL;
    range_t *r = NULL;
    uint boxes = 0;
    uint space = 0;

    if (mr == NULL)
	return;
    if (mr->type == MOTIF_SIMPLE) {
//      printf("Simple motif\n");
//      printf("motif: %s\n", mr->mdata.simple_motif->word);
//      printf("degeneration: %d\n", mr->mdata.simple_motif->deg);
	fprintf(options.output_file, "%-30s\t%3d of %-3d\t%e\n",
		mr->mdata.simple_motif->word,
		olist_noccseqs(mr->occurrences), options.seqn, mr->pvalue);
    } else {
//      printf("Complex motif\n");
//      printf("Number of boxes: %d\n",
//             smlist_nsmotifs(mr->mdata.complex_motif->boxes));
	boxes = smlist_nsmotifs(mr->mdata.complex_motif->boxes);
	space = 30;

	i = smlist_iterate_reset(mr->mdata.complex_motif->boxes);
	ri = rlist_iterate_reset(mr->mdata.complex_motif->ranges);

	while (smlist_iterate_has_next(i)) {
	    sm = smlist_iterate_next(i);
//          printf("%s(%d)", sm->word, sm->deg);
	    boxes--;
	    space -= 10;
	    fprintf(options.output_file, "%-5s", sm->word);
	    if (!boxes)
		while (space--)
		    fprintf(options.output_file, " ");

	    if (rlist_iterate_has_next(ri)) {
		r = rlist_iterate_next(ri);
		if (r->min != r->max)
		    fprintf(options.output_file, " <%d,%d> ", r->min,
			    r->max);
		else
		    fprintf(options.output_file, " <%d> ", r->min);
	    }
	}

	fprintf(options.output_file, "\t%3d of %-3d\t%e\n",
		olist_noccseqs(mr->occurrences), options.seqn, mr->pvalue);

	smlist_iterate_finish(i);
	rlist_iterate_finish(ri);
    }


}
