#ifndef MUSA_MOTIF_REPORT_H
#define MUSA_MOTIF_REPORT_H

#include "motif_report.h"

void print_motif_report(motif_report_t *);

#endif
