#ifndef SEED_H
#define SEED_H

#include "bitmask.h"
#include "definitions.h"

typedef struct seed_str {
    score_t score;
    bool_t is_diag;
    bitmask_t *mask;
} seed_t;

seed_t *creat_seed(score_t, bool_t, bitmask_t *);
void destroy_seed(seed_t *);


#endif
