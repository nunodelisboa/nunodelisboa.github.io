#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "sequences.h"
#include "util.h"
#include "definitions.h"
#include "options.h"
#include "debug.h"

extern options_t options;

profile_t *generate_profile(dataset_t * ds)
{
    profile_t *p = NULL;
    int i = 0, j = 0, k = 0;
    motif_t motif = 0;
    int terminus = 0;

    p = (profile_t *) safe_malloc(sizeof(profile_t));

    p->seqn = ds->seqn;

    p->seqlen = (uint *) safe_malloc(sizeof(uint) * ds->seqn);
    p->fpositions = (void *) safe_malloc(sizeof(void *) * ds->seqn);

    if (options.bothstrands)
	p->rpositions = (void *) safe_malloc(sizeof(void *) * ds->seqn);
    else
	p->rpositions = NULL;

    for (i = 0; i < ds->seqn; i++) {
	if (ds->sequences[i] != NULL)
	    p->seqlen[i] = strlen(ds->sequences[i]);
	else
	    p->seqlen[i] = 0;

	p->fpositions[i] =
	    (void *) safe_malloc(sizeof(void *) * MERS(options.lambda));

	for (j = 0; j < MERS(options.lambda); j++)
	    p->fpositions[i][j] = NULL;

	terminus = p->seqlen[i] - options.lambda;
	for (k = 0; k <= terminus; k++) {
	    motif = str2motif(ds->sequences[i], k, options.lambda);
	    if (p->fpositions[i][motif] == NULL)
		p->fpositions[i][motif] = creat_ilist(WITH_REPETITION);
	    ilist_add_int(p->fpositions[i][motif], k);
	}

	if (options.bothstrands) {
	    p->rpositions[i] =
		(void *) safe_malloc(sizeof(void *) *
				     MERS(options.lambda));

	    for (j = 0; j < MERS(options.lambda); j++)
		p->rpositions[i][j] = NULL;

	    for (k = terminus; k >= 0; k--) {
		motif = str2rcmotif(ds->sequences[i], k, options.lambda);
		if (p->rpositions[i][motif] == NULL)
		    p->rpositions[i][motif] = creat_ilist(WITH_REPETITION);
		ilist_add_int(p->rpositions[i][motif],
			      p->seqlen[i] - k - options.lambda);
	    }

	}

    }

    return p;
}

char *motif2str(motif_t motif)
{
    ushort lambda = options.lambda;
    char *s = NULL;
    char alpha[] = {
	'A', 'C', 'G', 'T'
    };
    int i = 0, n = 0;
    s = (char *) safe_malloc(sizeof(char) * (lambda + 1));
    n = motif;
    for (i = 1; i <= lambda; i++) {
	s[lambda - i] = alpha[n % 4];
	n /= 4;
    }
    s[lambda] = '\0';
    return s;
}

motif_t str2motif(char *seq, uint pos, ushort lambda)
{
    motif_t motif = 0;
    int i = 0;
    for (i = 0; i < lambda; i++) {
	motif *= 4;
	switch (seq[i + pos]) {
	case 'A':
	case 'a':
	    motif += 0;
	    break;
	case 'C':
	case 'c':
	    motif += 1;
	    break;
	case 'G':
	case 'g':
	    motif += 2;
	    break;
	case 'T':
	case 't':
	    motif += 3;
	    break;
	default:
	    break;
	}
    }
//    fprintf(stderr, "str2motif reported %d\n", motif); 
    return motif;
}

motif_t str2rcmotif(char *seq, uint pos, ushort lambda)
{
    motif_t motif = 0;
    uint i = 0;
    uint factor = 1;
    for (i = 0; i < lambda; i++) {
	switch (seq[i + pos]) {
	case 'A':
	case 'a':
	    motif += 3 * factor;
	    break;
	case 'C':
	case 'c':
	    motif += 2 * factor;
	    break;
	case 'G':
	case 'g':
	    motif += 1 * factor;
	    break;
	case 'T':
	case 't':
	    motif += 0;
	    break;
	default:
	    break;
	}
	factor *= 4;
    }
//    fprintf(stderr, "str2rcmotif reported %d\n", motif);
    return motif;
}


void destroy_profile(profile_t * p)
{

    int i = 0, j = 0;
    for (i = 0; i < p->seqn; i++) {
	for (j = 0; j < MERS(options.lambda); j++) {
	    ilist_destroy(p->fpositions[i][j]);
	    if (options.bothstrands)
		ilist_destroy(p->rpositions[i][j]);
	}
	safe_free(p->fpositions[i]);
	if (options.bothstrands)
	    safe_free(p->rpositions[i]);
    }
    safe_free(p->fpositions);
    if (options.bothstrands)
	safe_free(p->rpositions);
    safe_free(p->seqlen);
    safe_free(p);
}

void print_profile(profile_t * p)
{
    int i = 0, j = 0;
    for (i = 0; i < p->seqn; i++) {
	for (j = 0; j < MERS(options.lambda); j++) {
	    message
		("positions[seq = %d][ motif = %d] has %d elements in the forward strand and %d elements in the reverse strand",
		 i, j, ilist_nints(p->fpositions[i][j]),
		 ilist_nints(p->rpositions[i][j]));
	}
    }

}
