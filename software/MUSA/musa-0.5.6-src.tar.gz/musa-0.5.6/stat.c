/*

        API functions for libstat

        by Nuno D. Mendes
	$Id: stat.c,v 1.18 2007/04/16 15:13:13 nnmen Exp $


*/

#include <string.h>
#include <math.h>

#include "stat.h"
#include "util.h"
#include "motif_report.h"
#include "sequence_extra.h"

#define _N_ 0
#define _A_ 1
#define _C_ 2
#define _G_ 3
#define _T_ 4

#define ASIZE 4

stat_model_t *stat_model(dataset_t * ds)
{
    stat_model_t *sm = NULL;
    char *seq = NULL;
    uint i = 0, j = 0;
    uint asize = ASIZE + 1;	/* alphabet size plus 1 */

    sm = (stat_model_t *) safe_malloc(sizeof(stat_model_t));

    sm->seqlen = 0;
    sm->seqn = ds->seqn;
    sm->p = (double *) safe_calloc(asize, sizeof(double));
    sm->A = (double **) safe_malloc(sizeof(double *) * asize);

    for (i = 0; i < asize; i++)
	sm->A[i] = (double *) safe_calloc(asize, sizeof(double));

    for (i = 0; i < ds->seqn; i++) {
	seq = ds->sequences[i];
	j = 0;
	while (seq[j]) {
	    sm->p[_N_]++;
	    switch (seq[j]) {
	    case 'A':
		sm->p[_A_]++;
		if (seq[j + 1]) {
		    sm->A[_A_][_N_]++;
		    switch (seq[j + 1]) {
		    case 'A':
			sm->A[_A_][_A_]++;
			break;
		    case 'C':
			sm->A[_A_][_C_]++;
			break;
		    case 'G':
			sm->A[_A_][_G_]++;
			break;
		    case 'T':
			sm->A[_A_][_T_]++;
			break;
		    }
		}
		break;
	    case 'C':
		sm->p[_C_]++;
		if (seq[j + 1]) {
		    sm->A[_C_][_N_]++;
		    switch (seq[j + 1]) {
		    case 'A':
			sm->A[_C_][_A_]++;
			break;
		    case 'C':
			sm->A[_C_][_C_]++;
			break;
		    case 'G':
			sm->A[_C_][_G_]++;
			break;
		    case 'T':
			sm->A[_C_][_T_]++;
			break;
		    }
		}

		break;
	    case 'G':
		sm->p[_G_]++;
		if (seq[j + 1]) {
		    sm->A[_G_][_N_]++;
		    switch (seq[j + 1]) {
		    case 'A':
			sm->A[_G_][_A_]++;
			break;
		    case 'C':
			sm->A[_G_][_C_]++;
			break;
		    case 'G':
			sm->A[_G_][_G_]++;
			break;
		    case 'T':
			sm->A[_G_][_T_]++;
			break;
		    }
		}

		break;
	    case 'T':
		sm->p[_T_]++;
		if (seq[j + 1]) {
		    sm->A[_T_][_N_]++;
		    switch (seq[j + 1]) {
		    case 'A':
			sm->A[_T_][_A_]++;
			break;
		    case 'C':
			sm->A[_T_][_C_]++;
			break;
		    case 'G':
			sm->A[_T_][_G_]++;
			break;
		    case 'T':
			sm->A[_T_][_T_]++;
			break;
		    }
		}

		break;
	    }

	    j++;
	}
	sm->seqlen += j;

    }

    for (i = 1; i <= 4; i++) {
	sm->p[i] = sm->p[i] / sm->p[_N_];
	for (j = 1; j <= 4; j++) {
	    sm->A[i][j] = sm->A[i][j] / sm->A[i][_N_];
	}
    }

    sm->seqlen /= ds->seqn;
#ifdef MUSA_DEBUG
    print_stat_model(sm);
#endif

    return sm;

}

void print_stat_model(stat_model_t * m)
{
    if (m->p)
	fprintf(stderr, "p = [%g %g %g %g]\n", m->p[1], m->p[2], m->p[3],
		m->p[4]);
    fprintf(stderr,
	    "A\n[%g %g %g %g]\n[%g %g %g %g]\n[%g %g %g %g]\n[%g %g %g %g]\n",
	    m->A[1][1], m->A[1][2], m->A[1][3], m->A[1][4], m->A[2][1],
	    m->A[2][2], m->A[2][3], m->A[2][4], m->A[3][1], m->A[3][2],
	    m->A[3][3], m->A[3][4], m->A[4][1], m->A[4][2], m->A[4][3],
	    m->A[4][4]);
    fprintf(stderr, "seqlen = %g\n", (double) m->seqlen);

}

void destroy_stat_model(stat_model_t * m)
{
    uint asize = ASIZE + 1;
    uint i = 0;
    if (m == NULL)
	return;

    safe_free(m->p);
    for (i = 0; i < asize; i++)
	safe_free(m->A[i]);
    safe_free(m->A);
    safe_free(m);

}

stat_model_t *power_model(stat_model_t * m, uint power)
{
    stat_model_t *n, *t = NULL;
    uint asize = ASIZE + 1;	/* alphabet size plus one */
    uint i = 0, j = 0, k = 0;

    n = (stat_model_t *) safe_malloc(sizeof(stat_model_t));
    n->p = (double *) safe_calloc(asize, sizeof(double));
    n->A = (double **) safe_malloc(sizeof(double *) * asize);
    n->seqlen = m->seqlen;
    for (i = 0; i < asize; i++) {
	n->A[i] = (double *) safe_calloc(asize, sizeof(double));
	n->p[i] = m->p[i];
    }

    if (power <= 1) {
	for (i = 0; i < asize; i++)
	    for (j = 0; j < asize; j++)
		n->A[i][j] = m->A[i][j];

	return n;
    } else {
	t = power_model(m, power - 1);
	for (i = 1; i < asize; i++)
	    for (j = 1; j < asize; j++)
		for (k = 1; k < asize; k++)
		    n->A[i][j] += t->A[i][k] * m->A[k][j];

	destroy_stat_model(t);
	return n;
    }

}

uint code(char c)
{
    switch (c) {
    case 'A':
    case 'a':
	return _A_;
    case 'C':
    case 'c':
	return _C_;
    case 'G':
    case 'g':
	return _G_;
    case 'T':
    case 't':
	return _T_;
    default:
	return 0;
    }
}



mrlist_t *stat_evaluate(mrlist_t * ml, stat_model_t * m,
			bool_t bothstrands)
{

    motif_report_t *mr = NULL;
    mriterator_t *i = NULL;
    uint nmotifs = 0;
    char *m1 = NULL, *m2 = NULL;
    uint e1 = 0, e2 = 0;
    uint dmin = 0, dmax = 0;
    smiterator_t *smi = NULL;
    riterator_t *ri = NULL;
    range_t *range = NULL;
    smotif_t *sm = NULL;

    nmotifs = mrlist_nmotif_reports(ml);

    i = mrlist_iterate_reset(ml);
    while (mrlist_iterate_has_next(i)) {
	mr = mrlist_iterate_next(i);

	if (motif_report_type(mr) == MOTIF_COMPLEX
	    && smlist_nsmotifs(mr->mdata.complex_motif->boxes) > 2) {
	    mr->pvalue = 0.0;
	    continue;
	}

	if (motif_report_type(mr) == MOTIF_COMPLEX) {
	    smi = smlist_iterate_reset(mr->mdata.complex_motif->boxes);
	    if (smlist_iterate_has_next(smi)) {
		sm = smlist_iterate_next(smi);
		m1 = sm->word;
		e1 = sm->deg;
	    }
	    if (smlist_iterate_has_next(smi)) {
		sm = smlist_iterate_next(smi);
		m2 = sm->word;
		e2 = sm->deg;
	    }
	    smlist_iterate_finish(smi);

	    ri = rlist_iterate_reset(mr->mdata.complex_motif->ranges);
	    if (rlist_iterate_has_next(ri)) {
		range = rlist_iterate_next(ri);
		dmin = range->min;
		dmax = range->max;
	    }
	    rlist_iterate_finish(ri);

	    if (e1 || e2) {
		mr->pvalue =
		    pvalue(olist_noccseqs(mr->occurrences),
			   s_gamma_errors(m1, m2, dmin, dmax, e1, e2, m, 2,
					  bothstrands), m->seqn);
	    } else {

		mr->pvalue =
		    pvalue(olist_noccseqs(mr->occurrences),
			   s_gamma(m1, m2, dmin, dmax, m, 2, bothstrands),
			   m->seqn);
#ifdef MUSA_DEBUG
		fprintf(stderr,
			"pvalue(%d,s_gamma(%s,%s,%d,%d,model,2,%d),%d)  == %g\n",
			olist_noccseqs(mr->occurrences), m1, m2, dmin,
			dmax, bothstrands, m->seqn, mr->pvalue);
#endif

	    }

	} else {

	    if (e1 || e2) {

		mr->pvalue =
		    pvalue(olist_noccseqs(mr->occurrences),
			   s_gamma_errors(mr->mdata.simple_motif->word,
					  NULL, 0, 0,
					  mr->mdata.simple_motif->deg, 0,
					  m, 1, bothstrands), m->seqn);

	    } else {


		mr->pvalue =
		    pvalue(olist_noccseqs(mr->occurrences),
			   s_gamma(mr->mdata.simple_motif->word, NULL, 0,
				   0, m, 1, bothstrands), m->seqn);
#ifdef MUSA_DEBUG
		fprintf
		    (stderr,
		     "pvalue(%d,s_gamma(%s,NULL,0,0,model,2,%d),%d) == %g\n\n",
		     olist_noccseqs(mr->occurrences),
		     mr->mdata.simple_motif->word, bothstrands, m->seqn,
		     mr->pvalue);
#endif
	    }


	}

    }

    mrlist_iterate_finish(i);

    return ml;
}


double pvalue(uint obs, double p, uint n)
{
    double r = 0.0;
    int i;
    for (i = obs; i <= n; i++) {
	r += pdf_Binomial(i, n, p);
    }
#ifdef MUSA_DEBUG
    fprintf(stderr, "pvalue(obs=%d,p=%g,n=%d) == %g\n", obs, p, n, r);
#endif
    return r;
}

double pdf_Binomial(uint k, uint n, double p)
{
    double r = 0.0;
    r = binomial_coeff(n, k) * pow(p, k) * pow(1.0 - p, n - k);
#ifdef MUSA_DEBUG
    fprintf(stderr, "pdf_Binomial(k=%d,n=%d,p=%g) == %g\n", k, n, p, r);
#endif
    return r;
}

uint binomial_coeff(uint n, uint k)
{
    uint i = 0;
    uint r = n - k + 1;
    for (i = 2; i <= k; i++)
	r *= (n - k + i) / i;
#ifdef MUSA_DEBUG
    fprintf(stderr, "binomial_coeff(n=%d,k=%d) == %d\n", n, k, r);
#endif
    return r;
}

/** s_gamma without errors **/
double s_gamma(char *m1, char *m2, uint dmin, uint dmax,
	       stat_model_t * m, uint boxes, bool_t bothstrands)
{
    uint l = m->seqlen;
    double r = 0.0;
    double p1 = 0.0, p2 = 0.0;
    char *rm1 = NULL, *rm2 = NULL;

    if (boxes == 1) {
	p1 = prob_monad(m1, m);
	if (bothstrands) {
	    rm1 = reverse_seq(m1);
	    p2 = prob_monad(rm1, m);
	    safe_free(rm1);
	}

	r = 1 - pow(1 - p1 - p2, l - strlen(m1) + 1);
    }

    if (boxes == 2) {
	p1 = prob_dyad(m1, m2, dmin, dmax, m);
	if (bothstrands) {
	    rm1 = reverse_seq(m1);
	    rm2 = reverse_seq(m2);
	    p2 = prob_dyad(rm2, rm1, dmin, dmax, m);
	    safe_free(rm1);
	    safe_free(rm2);
	}

	r = 1 - pow(1 - p1 - p2, l - strlen(m1) - strlen(m2) + 1);
    }
#ifdef MUSA_DEBUG
    fprintf
	(stderr,
	 "s_gamma(m1=%s,m2=%s,dmin=%d,dmax=%d,model,boxes=%d,bothstrands=%d) l=%d == %g\n",
	 m1, m2, dmin, dmax, boxes, bothstrands, l, r);
#endif


    return r;
}

double s_gamma_errors(char *m1, char *m2, uint dmin, uint dmax, uint e1,
		      uint e2, stat_model_t * m, uint boxes,
		      bool_t bothstrands)
{

    uint l = m->seqlen;
    double r = 0.0;
    double p1 = 0.0, p2 = 0.0;
    char *rm1 = NULL, *rm2 = NULL;

    if (boxes == 1) {
	p1 = prob_monad_errors(m1, m, e1);
	if (bothstrands) {
	    rm1 = reverse_seq(m1);
	    p2 = prob_monad_errors(rm1, m, e1);
	    safe_free(rm1);
	}

	r = 1 - pow(1 - p1 - p2, l - strlen(m1) + 1);

    }

    if (boxes == 2) {

	p1 = prob_dyad_error(m1, m2, e1, e2, dmin, dmax, m);
	if (bothstrands) {
	    rm1 = reverse_seq(m1);
	    rm2 = reverse_seq(m2);
	    p2 = prob_dyad_error(rm2, rm1, e2, e1, dmin, dmax, m);
	    safe_free(rm1);
	    safe_free(rm2);
	}
	r = 1 - pow(1 - p1 - p2, l - strlen(m1) - strlen(m2) + 1);

    }

    return r;
}

double prob_monad(char *m, stat_model_t * model)
{
    uint i = 0;
    double r = 0.0;

    r = model->p[code(m[0])];
    for (i = 1; i < strlen(m); i++)
	r *= model->A[code(m[i - 1])][code(m[i])];
#ifdef MUSA_DEBUG
    fprintf(stderr, "prob_monad(%s,model) = %g\n", m, r);
#endif

    return r;
}

double prob_monad_errors(char *m, stat_model_t * model, uint e)
{
    bitmask_t *mask = NULL;
    double p = 0.0;

    mask = creat_bitmask(strlen(m));
    p = _monad_errors(m, model, e, mask, 0);
    bitmask_destroy(mask);
    return p;

}


double _monad_errors(char *m, stat_model_t * model, uint e,
		     bitmask_t * mask, uint start)
{
    uint offset = 0;
    uint l = 0;
    uint jump = 0;
    char i, f;			/* initial and final jump character */
    uint p = 0;
    uint state = 0;
    char *motif = NULL;
    stat_model_t *pm = NULL;

    double prob = 0.0;


    if (e) {
	/* expand tree of all error attributions */
	for (p = 0; p < strlen(m); p++) {
	    if (p < start || bitmask_isset(mask, p))
		continue;
	    bitmask_set(mask, p);
	    prob += _monad_errors(m, model, e - 1, mask, p);
	    bitmask_unset(mask, p);
	}
    } else {
	/* all errors have been attributed */

	while (p < strlen(m)) {
	    switch (state) {
	    case 0:		/* beginning of pattern */
		if (bitmask_isset(mask, p)) {
		    offset++;	/* ignore degenerate head */
		} else {
		    state = 1;	/* start of undegenerate chunk */
		    l++;
		}
		break;
	    case 1:		/* undegenerate chunk */
		if (bitmask_isset(mask, p)) {
		    motif = (char *) safe_malloc(sizeof(char) * (l + 1));
		    strncpy(motif, m + offset, l);
		    prob += log(prob_monad(motif, model));
		    safe_free(motif);
		    i = m[offset + l - 1];
		    jump++;
		    state = 2;	/* beginning of degenerate gap */
		} else {
		    l++;	/* extend undegenerate chunk */
		}
		break;
	    case 2:		/* degenerate gap */
		if (bitmask_isset(mask, p)) {
		    jump++;	/* extend gap */
		} else {
		    offset += l + jump;
		    l = 1;
		    f = m[offset];
		    pm = power_model(model, jump + 1);
		    prob += log(pm->A[code(i)][code(f)]);
		    destroy_stat_model(pm);
		    prob -= log(model->p[code(f)]);
		    jump = 0;
		    state = 1;	/* beginning of undegenerate chunk */
		}
		break;
	    }

	    p++;
	}

	if (state == 1) {	/* undegenerate tail */
	    motif = (char *) safe_malloc(sizeof(char) * (l + 1));
	    strncpy(motif, m + offset, l);
	    prob += log(prob_monad(motif, model));
	    safe_free(motif);
	}

	prob = exp(prob);

    }

    return prob;
}

double prob_dyad(char *m1, char *m2, uint dmin, uint dmax,
		 stat_model_t * model)
{
    double r = 0.0;
    stat_model_t *pm = NULL;

    /* for the sake of simplicity we approach this calculation 
       by using only dmin */

    pm = power_model(model, dmin + 1);
#ifdef MUSA_DEBUG
    print_stat_model(pm);
#endif

    r = log(prob_monad(m1, model));
    r += log(pm->A[code(m1[strlen(m1) - 1])][code(m2[0])]);
    r += log(prob_monad(m2, model));
    r -= log(model->p[code(m2[0])]);

    destroy_stat_model(pm);

#ifdef MUSA_DEBUG
    fprintf(stderr, "prob_dyad(m1=%s,m2=%s,dmin=%d,dmax=%d,model) == %g\n",
	    m1, m2, dmin, dmax, exp(r));
#endif

    return exp(r);
}


double prob_dyad_error(char *m1, char *m2, uint dmin, uint dmax, uint e1,
		       uint e2, stat_model_t * model)
{

    double r = 0.0;
    stat_model_t *pm = NULL;

    /* for the sake of simplicity we approach this calculation
       by using only dmin */

    pm = power_model(model, dmin + 1);

    r = log(prob_monad_errors(m1, model, e1));
    r += log(pm->A[code(m1[strlen(m1) - 1])][code(m2[0])]);
    r += log(prob_monad_errors(m2, model, e2));
    r -= log(model->p[code(m2[0])]);

    destroy_stat_model(pm);

    return exp(r);



}
