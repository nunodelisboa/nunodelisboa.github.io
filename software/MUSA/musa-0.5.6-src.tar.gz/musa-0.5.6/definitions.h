/*

        General definitions

        by Nuno D. Mendes
	$Id: definitions.h,v 1.6 2007/03/02 16:40:25 nnmen Exp $


*/

#ifndef DEFINITIONS_H
#define DEFINITIONS_H

#define MERS(n) ipow(4,n)
#define QUIET	options.quiet
#define DEBUG_LEVEL (1-options.quiet)
#define DEBUG_HEAD "musa: "

/* Default values */
#define DEFAULT_MAXDIST		500
#define DEFAULT_MINDIST 	1
#define DEFAULT_EPSILON 	0
#define DEFAULT_LAMBDA 		4
#define DEFAULT_SIEVERATE 	10

#endif
