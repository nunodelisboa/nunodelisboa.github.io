#ifndef SLIST_H
#define SLIST_H

#include "list.h"
#include "seed.h"

typedef list_t slist_t;
typedef iterator_t siterator_t;

slist_t *creat_slist();
slist_t *slist_clone(slist_t *);
void slist_destroy(slist_t *);
slist_t *slist_add_seed(slist_t *, seed_t *);
seed_t *slist_get_first(slist_t *);
seed_t *slist_get_last(slist_t *);
seed_t *slist_get(slist_t *, unsigned int);
slist_t *slist_remove_seed(slist_t *, seed_t *);
uint slist_nseeds(slist_t *);

siterator_t *slist_iterate_reset(slist_t *);
siterator_t *slist_iterate_rewind(slist_t *);
int slist_iterate_has_next(siterator_t *);
int slist_iterate_has_previous(siterator_t *);
seed_t *slist_iterate_next(siterator_t *);
seed_t *slist_iterate_previous(siterator_t *);
void slist_iterate_finish(siterator_t *);

int seed_compare(seed_t *, seed_t *);
int seed_equal(seed_t *, seed_t *);
score_t seed_id(seed_t *);

#endif
