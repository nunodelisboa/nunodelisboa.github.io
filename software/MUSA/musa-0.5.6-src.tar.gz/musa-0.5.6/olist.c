/*

        List of occseq objects

        by Nuno D. Mendes
	$Id: olist.c,v 1.3 2007/03/02 16:40:25 nnmen Exp $


*/

#include <stdlib.h>
#include <stdio.h>

#include "list.h"
#include "olist.h"
#include "occseq.h"
#include "util.h"

olist_t *creat_olist()
{
    olist_t *list = NULL;
    list = creat_list((int (*)(void *, void *)) occseq_compare,
		      (int (*)(void *, void *)) occseq_equal,
		      (unsigned int (*)(void *)) occseq_id);
    return list;
}

olist_t *olist_clone(olist_t * l)
{
    olist_t *nl = NULL;
    oiterator_t *i = NULL;

    nl = creat_olist();
    i = olist_iterate_reset(l);
    while (olist_iterate_has_next(i))
	olist_add_occseq(nl, occseq_clone(olist_iterate_next(i)));
    olist_iterate_finish(i);

    return nl;
}

occseq_t *olist_get_first(olist_t * l)
{
    if (l == NULL)
	return NULL;
    return (occseq_t *) list_get_first(l);
}

void olist_destroy(olist_t * l)
{
    list_destroy(l);
}

void olist_deep_destroy(olist_t * l)
{
    oiterator_t *i = NULL;

    i = olist_iterate_reset(l);
    while (olist_iterate_has_next(i))
	destroy_occseq(olist_iterate_next(i));
    olist_iterate_finish(i);
    olist_destroy(l);

}

olist_t *olist_add_occseq(olist_t * list, occseq_t * d)
{

    if (list == NULL)
	return list;
    list = list_add_elem_t(list, d);
    return list;

}

uint olist_noccseqs(olist_t * list)
{
    if (list == NULL)
	return 0;
    return list_nelems(list);
}

oiterator_t *olist_iterate_reset(olist_t * l)
{
    return list_iterate_reset(l);
}

oiterator_t *olist_iterate_rewind(olist_t * l)
{
    return list_iterate_rewind(l);
}

int olist_iterate_has_next(oiterator_t * i)
{
    return list_iterate_has_next(i);
}

int olist_iterate_has_previous(oiterator_t * i)
{
    return list_iterate_has_previous(i);
}

occseq_t *olist_iterate_next(oiterator_t * i)
{
    return list_iterate_next(i);
}

occseq_t *olist_iterate_previous(oiterator_t * i)
{
    return list_iterate_previous(i);
}

void olist_iterate_finish(oiterator_t * i)
{
    list_iterate_finish(i);
}

int occseq_compare(occseq_t * r1, occseq_t * r2)
{
    return 0;
}

int occseq_equal(occseq_t * r1, occseq_t * r2)
{
    return 0;
}

int occseq_id(occseq_t * r)
{
    return 0;
}
