/*

        MUSA matcher functions

        by Nuno D. Mendes
	$Id: musa_matcher.c,v 1.3 2007/03/02 16:40:25 nnmen Exp $


*/

#include <stdlib.h>
#include "musa_matcher.h"
#include "motif_report.h"
#include "options.h"

extern options_t options;

mrlist_t *filter(mrlist_t * ml)
{
    motif_report_t *mr = NULL;
    mriterator_t *i = NULL;
    mrlist_t *new = NULL;

    new = creat_mrlist();

    i = mrlist_iterate_reset(ml);
    while (mrlist_iterate_has_next(i)) {
	mr = mrlist_iterate_next(i);
	if (olist_noccseqs(mr->occurrences) >= options.sieve)
	    mrlist_add_motif_report(new, mr);
	else
	    destroy_motif_report(mr);
    }
    mrlist_iterate_finish(i);
    mrlist_destroy(ml);

    return new;
}
