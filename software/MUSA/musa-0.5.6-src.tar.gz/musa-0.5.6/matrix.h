#ifndef MATRIX_H
#define MATRIX_H

#include "ilist.h"
#include "configuration.h"
#include "sequences.h"

typedef struct mentry_str {
    score_t score;
    ilist_t *distances;
} mentry_t;


typedef struct matrix_str {
    mentry_t ***entries;
} matrix_t;

matrix_t *generate_matrix(profile_t *);
void destroy_matrix(matrix_t *);

#endif
