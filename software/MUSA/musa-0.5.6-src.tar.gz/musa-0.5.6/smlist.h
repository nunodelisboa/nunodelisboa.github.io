/*

        Headers for smlist.c

        by Nuno D. Mendes	
	$Id: smlist.h,v 1.3 2007/03/02 16:40:26 nnmen Exp $


*/

#ifndef SMLIST_H
#define SMLIST_H

#include "list.h"
#include "smotif.h"

typedef list_t smlist_t;
typedef iterator_t smiterator_t;

smlist_t *creat_smlist();
void smlist_destroy(smlist_t *);
void smlist_deep_destroy(smlist_t *);
smlist_t *smlist_add_smotif(smlist_t *, smotif_t *);
smotif_t *smlist_get_first(smlist_t *);
smotif_t *smlist_get_last(smlist_t *);
smiterator_t *smlist_iterate_reset(smlist_t *);
smiterator_t *smlist_iterate_rewind(smlist_t *);
int smlist_iterate_has_next(smiterator_t *);
int smlist_iterate_has_previous(smiterator_t *);
smotif_t *smlist_iterate_next(smiterator_t *);
smotif_t *smlist_iterate_previous(smiterator_t *);
void smlist_iterate_finish(smiterator_t *);
unsigned int smlist_nsmotifs(smlist_t *);
int smotif_compare(smotif_t *, smotif_t *);
int smotif_equal(smotif_t *, smotif_t *);
int smotif_id(smotif_t *);



#endif
