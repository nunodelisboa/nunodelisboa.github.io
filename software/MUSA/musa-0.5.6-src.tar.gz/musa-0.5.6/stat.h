/*

        Headers and definitions for stat.c

        by Nuno D. Mendes
        $Id: stat.h,v 1.9 2007/04/03 11:39:12 nnmen Exp $

*/

#ifndef STAT_H
#define STAT_H

#include "sequences.h"
#include "bitmask.h"
#include "mrlist.h"

typedef struct stat_model_str {
    double *p;
    double **A;
    uint seqlen;
    uint seqn;
} stat_model_t;

stat_model_t *stat_model(dataset_t *);
mrlist_t *stat_evaluate(mrlist_t *, stat_model_t *, bool_t);
void destroy_stat_model(stat_model_t *);
void print_stat_model(stat_model_t *);

double pvalue(uint, double, uint);
double s_gamma(char *, char *, uint, uint, stat_model_t *, uint, bool_t);
double s_gamma_errors(char *, char *, uint, uint, uint, uint,
		      stat_model_t *, uint, bool_t);

double pdf_Binomial(uint, uint, double);
uint binomial_coeff(uint, uint);

double prob_monad(char *, stat_model_t *);
double prob_monad_errors(char *, stat_model_t *, uint);
double prob_dyad(char *, char *, uint, uint, stat_model_t *);
double prob_dyad_error(char *, char *, uint, uint, uint, uint,
		       stat_model_t *);

double _monad_errors(char *, stat_model_t *, uint, bitmask_t *, uint);



#endif
