/*

        Definitions for sequence dataset manipulation

        by Nuno D. Mendes
        $Id: sequences.h,v 1.5 2007/03/02 16:40:25 nnmen Exp $

*/

#ifndef SEQUENCES_H
#define SEQUENCES_H

#include "ilist.h"
#include "types.h"

typedef struct dataset_str {
    ushort seqn;
    char **sequences;
} dataset_t;

dataset_t *creat_dataset(ushort, char **);
void destroy_dataset(dataset_t *);

typedef struct profile_str {
    ushort seqn;
    uint *seqlen;
    ilist_t ***fpositions;
    ilist_t ***rpositions;
} profile_t;

profile_t *generate_profile(dataset_t *);
void print_profile(profile_t *);
motif_t str2motif(char *, uint, ushort);
motif_t str2rcmotif(char *, uint, ushort);
char *motif2str(motif_t);
void destroy_profile(profile_t *);

#endif
