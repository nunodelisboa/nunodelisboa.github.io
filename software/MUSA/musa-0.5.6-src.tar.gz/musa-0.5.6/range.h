/*

        Headers for range.c

        by Nuno D. Mendes	
	$Id: range.h,v 1.3 2007/03/02 16:40:25 nnmen Exp $


*/

#ifndef DISTANCE_H
#define DISTANCE_H

#include "types.h"

typedef struct range_str {
    ushort min;
    ushort max;
} range_t;

range_t *creat_range(ushort min, ushort max);
range_t *range_clone(range_t * d);
void range_destroy(range_t * d);

#endif
