#ifndef ASSEMBLY_H
#define ASSEMBLY_H

#include "bicluster.h"

char *motif_assembly(bicluster_t *);

#endif
