/*

        Sequence manipulation helper functions

        by Nuno D. Mendes
	$Id: sequence_extra.c,v 1.4 2007/03/06 16:45:15 nnmen Exp $


*/


#include <stdlib.h>
#include <string.h>
#include "util.h"
#include "definitions.h"

char *reverse_seq(char *seq)
{
    char *rev = NULL;
    uint len = 0, i = 0;
    len = strlen(seq);
    rev = (char *) safe_malloc(sizeof(char) * (len + 1));
    for (i = 1; i <= len; i++)
	switch (seq[i - 1]) {
	case 'A':
	case 'a':
	    rev[len - i] = 'T';
	    break;
	case 'T':
	case 't':
	    rev[len - i] = 'A';
	    break;
	case 'C':
	case 'c':
	    rev[len - i] = 'G';
	    break;
	case 'G':
	case 'g':
	    rev[len - i] = 'C';
	    break;
	default:
	    rev[len - i] = seq[i];
	    break;
	}
    rev[len] = '\0';
    return rev;
}

char *invert_seq(char *seq)
{
    char *inv = NULL;
    uint len = 0, i = 0;
    len = strlen(seq);
    inv = (char *) safe_malloc(sizeof(char) * (len + 1));
    for (i = 1; i <= len; i++)
	inv[len - i] = seq[i - 1];
    inv[len] = '\0';
    return inv;
}
