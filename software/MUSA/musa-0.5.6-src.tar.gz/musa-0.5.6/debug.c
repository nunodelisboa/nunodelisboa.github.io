/*

        Debug reporter functions

        by Nuno D. Mendes
	$Id: debug.c,v 1.6 2007/03/06 16:49:30 nnmen Exp $


*/

#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>

#include "debug.h"

#ifdef MUSA
#include "definitions.h"
#include "options.h"
options_t options;
#endif

#ifdef RISO
#define DEBUG_HEAD "riso: "
#endif

#ifndef DEBUG_HEAD
#define DEBUG_HEAD " :"
#endif

void _debug(unsigned int fatal, unsigned nl, char *format, va_list ap)
{
    char head[] = DEBUG_HEAD;
    char cfatal[] = "** FATAL ";

    if (fatal)
	fprintf(stderr, cfatal);
    if (nl)
	fprintf(stderr, head);

    vfprintf(stderr, format, ap);

    if (nl)
	fprintf(stderr, "\n");

}

void debug(int level, char *format, va_list ap)
{
#ifdef DEBUG_LEVEL
    if (level <= DEBUG_LEVEL)
#endif
	_debug(0, 1, format, ap);
}

void debug_l(int level, char *format, va_list ap)
{
#ifdef DEBUG_LEVEL
    if (level <= DEBUG_LEVEL)
#endif
	_debug(0, 0, format, ap);
}

void debug_nl(int level)
{
#ifdef DEBUG_LEVEL
    if (level <= DEBUG_LEVEL)
#endif
	fprintf(stderr, "\n");
}

void error(char *format, ...)
{
    va_list ap;

    va_start(ap, format);
    _debug(1, 1, format, ap);
    va_end(ap);
    exit(-1);
}

void warn(char *format, ...)
{
    va_list ap;

    va_start(ap, format);
    debug(1, format, ap);
    va_end(ap);
}

void message(char *format, ...)
{
    va_list ap;

    va_start(ap, format);
    debug(1, format, ap);
    va_end(ap);
}

void message_l(char *format, ...)
{
    va_list ap;
    va_start(ap, format);
    debug_l(1, format, ap);
    va_end(ap);
}

void say(char *format, ...)
{
    va_list ap;
    va_start(ap, format);
    debug_l(1, format, ap);
    va_end(ap);
}

void say_nl()
{
    debug_nl(1);
}
