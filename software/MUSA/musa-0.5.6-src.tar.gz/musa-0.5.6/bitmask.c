/*

        Functions for arbitrary size bitmask manipulation

        by Nuno D. Mendes
	$Id: bitmask.c,v 1.7 2007/03/02 16:40:25 nnmen Exp $


*/

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <assert.h>

#include "bitmask.h"
#include "util.h"

bitmask_t *creat_bitmask(uint size)
{
    bitmask_t *m = NULL;

    m = (bitmask_t *) safe_malloc(sizeof(bitmask_t));
    m->size = size;
    m->blocks = size / (sizeof(uint) * 8);
    if (size % (sizeof(uint) * 8))
	m->blocks++;

    m->mask = (mask_t *) safe_malloc(sizeof(mask_t) * m->blocks);
    bzero(m->mask, sizeof(mask_t) * m->blocks);

    return m;
}

uint bitmask_size(bitmask_t * m)
{
    if (m != NULL)
	return m->size;
    else
	return 0;
}

bitmask_t *bitmask_set(bitmask_t * m, uint i)
{
    uint block = 0;
    uint offset = 0;
    mask_t mask = 0x01;

    block = i / (sizeof(uint) * 8);
    offset = i % (sizeof(uint) * 8);

    if (block > m->blocks)
	return m;
    m->mask[block] = m->mask[block] | (mask << offset);

    return m;
}


bitmask_t *bitmask_unset(bitmask_t * m, uint i)
{
    uint block = 0;
    uint offset = 0;
    mask_t mask = 0x01;

    block = i / (sizeof(uint) * 8);
    offset = i % (sizeof(uint) * 8);

    if (block > m->blocks)
	return m;
    m->mask[block] = m->mask[block] & ~(mask << offset);

    return m;
}


bitmask_t *bitmask_and(bitmask_t * m, bitmask_t * n)
{
    uint blocks = 0;
    int i = 0;
    bitmask_t *res = NULL;

    res = m;
    blocks = m->blocks;
    if (blocks > n->blocks) {
	blocks = n->blocks;
    }

    for (i = 0; i < blocks; i++) {
	res->mask[i] = m->mask[i] & n->mask[i];
    }

    return res;
}

bitmask_t *bitmask_or(bitmask_t * m, bitmask_t * n)
{
    uint blocks = 0;
    int i = 0;
    bitmask_t *res = NULL;

    res = m;
    blocks = m->blocks;
    if (blocks > n->blocks) {
	blocks = n->blocks;
    }

    for (i = 0; i < blocks; i++) {
	res->mask[i] = m->mask[i] | n->mask[i];
    }

    return res;
}

bool_t bitmask_compare(bitmask_t * m, bitmask_t * n)
{

    int i = 0;

    if (m->blocks != n->blocks)
	return 0;

    for (i = 0; i < m->blocks; i++) {
	if (m->mask[i] != n->mask[i])
	    return 0;
    }

    return 1;
}

bool_t bitmask_includes(bitmask_t * m, bitmask_t * n)
{
    int i = 0;
    if (m->blocks != n->blocks)
	return 0;

    for (i = 0; i < m->blocks; i++) {
	if ((m->mask[i] | n->mask[i]) != m->mask[i])
	    return 0;
    }

    return 1;

}


bool_t bitmask_isset(bitmask_t * m, uint i)
{
    uint block = 0;
    uint offset = 0;
    mask_t mask = 0x01;
    mask_t res = 0x00;

    block = i / (sizeof(uint) * 8);
    offset = i % (sizeof(uint) * 8);

    mask = mask << offset;
    res = mask & m->mask[block];

    return res == mask;
}

bitmask_t *bitmask_clone(bitmask_t * m)
{
    bitmask_t *new = NULL;
    int i = 0;

    if (m == NULL)
	return new;

    new = creat_bitmask(m->blocks * sizeof(uint) * 8);
    for (i = 0; i < m->blocks; i++)
	new->mask[i] = m->mask[i];

    return new;
}

void bitmask_destroy(bitmask_t * m)
{
    safe_free(m->mask);
    safe_free(m);
}

void test_bitmask()
{

    bitmask_t *m = NULL, *n = NULL, *p = NULL;
    uint size = 1024;

    m = creat_bitmask(size);
    n = creat_bitmask(size);

    bitmask_set(m, 523);
    assert(bitmask_isset(m, 523));
    bitmask_set(n, 522);
    assert(bitmask_isset(n, 522));

    n = bitmask_and(n, m);
    assert(!bitmask_isset(n, 523));
    assert(!bitmask_isset(n, 522));

    n = bitmask_or(n, m);
    assert(bitmask_isset(n, 523));

    assert(!bitmask_isset(n, 0));
    bitmask_set(n, 0);
    assert(bitmask_isset(n, 0));
    bitmask_unset(n, 0);
    assert(!bitmask_isset(n, 0));
    p = bitmask_clone(n);
    bitmask_and(n, p);
    assert(bitmask_compare(n, p));

    bitmask_destroy(m);
    bitmask_destroy(n);
    bitmask_destroy(p);

}

void bitmask_dump(bitmask_t * m)
{
    int i = 0;
    fprintf(stderr, "BITMASK(blocks=%d,\n\t", m->blocks);
    for (i = 0; i < m->blocks; i++) {
	fprintf(stderr, "mask[%d]=%d\n\t", i, m->mask[i]);
    }
    fprintf(stderr, ")\n");

}
