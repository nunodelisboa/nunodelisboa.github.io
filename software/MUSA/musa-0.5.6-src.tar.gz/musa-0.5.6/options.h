/*

        Definition of the options for MUSA

        by Nuno D. Mendes
	$Id: options.h,v 1.7 2007/03/02 16:40:25 nnmen Exp $


*/

#ifndef OPTIONS_H
#define OPTIONS_H

#include <stdio.h>
#include "types.h"

typedef struct options_str {
    ushort lambda;
    ushort epsilon;
    ushort seqn;
    ushort sieve;
    ushort sieverate;
    bool_t quiet;
    bool_t statistics;
    bool_t dump_mesh;
    bool_t bothstrands;
    distance_t mindist;
    distance_t maxdist;
    FILE *output_file;
} options_t;



#endif
