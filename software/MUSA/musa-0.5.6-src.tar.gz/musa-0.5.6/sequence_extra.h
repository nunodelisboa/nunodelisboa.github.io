/*

        Header for sequence_extra.c

        by Nuno D. Mendes
        $Id: sequence_extra.h,v 1.2 2007/03/04 20:05:30 nnmen Exp $


*/

#ifndef SEQUENCE_EXTRA_H
#define SEQUENCE_EXTRA_H

char *reverse_seq(char *);
char *invert_seq(char *);

#endif
