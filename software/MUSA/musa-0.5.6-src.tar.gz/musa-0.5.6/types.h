/*

        Global type definitions

        by Nuno D. Mendes
	$Id: types.h,v 1.2 2007/03/02 16:40:26 nnmen Exp $


*/

#ifndef TYPES_H
#define TYPES_H

typedef unsigned int uint;
typedef unsigned short ushort;
typedef unsigned int mask_t;
typedef unsigned char bool_t;
typedef short distance_t;
typedef unsigned int position_t;
typedef unsigned short score_t;
typedef unsigned short motif_t;

#endif
