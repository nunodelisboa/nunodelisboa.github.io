/*

        Motif reports

        by Nuno D. Mendes
	$Id: motif_report.c,v 1.10 2007/04/16 15:13:13 nnmen Exp $


*/


#include <string.h>
#include "motif_report.h"
#include "util.h"

motif_report_t *creat_motif_report(char *word, ushort error)
{
    motif_report_t *mr = NULL;
    static uint id = 0;

    mr = (motif_report_t *) safe_malloc(sizeof(motif_report_t));

    mr->id = ++id;
    mr->type = MOTIF_SIMPLE;
    mr->mdata.simple_motif = creat_smotif(word, error);
    mr->occurrences = NULL;
    mr->pvalue = 0.0;
    return mr;
}

motif_report_t *motif_report_add_box(motif_report_t * mr, char *word,
				     ushort mindist, ushort maxdist,
				     ushort error)
{

    smotif_t *sm = NULL;

    if (mr->type == MOTIF_SIMPLE) {
	mr->mdata.complex_motif = creat_cmotif(mr->mdata.simple_motif);
	mr->type = MOTIF_COMPLEX;

    }

    sm = creat_smotif(word, error);

    cmotif_add_box(mr->mdata.complex_motif, sm, mindist, maxdist);


    return mr;
}

uint motif_report_id(motif_report_t * mr)
{
    if (mr == NULL)
	return 0;
    return mr->id;
}

uint motif_report_noccurrences(motif_report_t * mr)
{
    uint count = 0;
    occseq_t *oc = NULL;
    oiterator_t *oi = NULL;

    if (mr == NULL)
	return count;

    oi = olist_iterate_reset(mr->occurrences);
    while (olist_iterate_has_next(oi)) {
	oc = olist_iterate_next(oi);
	count += ilist_nints(oc->pos_forward);
	count += ilist_nints(oc->pos_reverse);
    }
    olist_iterate_finish(oi);

    return count;
}

uint motif_report_nsequences(motif_report_t * mr)
{
    if (mr == NULL)
	return 0;
    return olist_noccseqs(mr->occurrences);

}

void destroy_motif_report(motif_report_t * mr)
{
    if (mr == NULL)
	return;

    if (mr->type == MOTIF_SIMPLE) {
	destroy_smotif(mr->mdata.simple_motif);
    } else {
	destroy_cmotif(mr->mdata.complex_motif);
    }
    olist_deep_destroy(mr->occurrences);
    safe_free(mr);
}

motif_report_t *buffer2motif_report(char *buffer, uint epsilon)
{
    motif_report_t *mr = NULL;
    uint distance = 0, nboxes = 0;
    char *box = NULL, *motif = NULL;
    char *p = NULL;

    p = buffer;
    box = (char *) safe_malloc(sizeof(char) * strlen(buffer));
    sscanf(p, "%d %s", &nboxes, box);
    motif = (char *) safe_malloc(sizeof(char) * (strlen(box) + 1));
    strcpy(motif, box);
    safe_free(box);
    mr = creat_motif_report(motif, 0);
    p += 2;			// space and nboxes
    p += strlen(motif) + 1;	// space and first box
    safe_free(motif);

    while (--nboxes) {
	box = (char *) safe_malloc(sizeof(char) * strlen(buffer));
	sscanf(p, "%d %s", &distance, box);
	motif = (char *) safe_malloc(sizeof(char) * (strlen(box) + 1));
	strcpy(motif, box);
	safe_free(box);
	motif_report_add_box
	    (mr, motif, distance - epsilon, distance + epsilon, 0);
	p += 1;
	while (distance) {
	    p += 1;
	    distance = distance / 10;
	}
	p += strlen(motif) + 1;
	safe_free(motif);
    }

    return mr;
}


motif_type_t motif_report_type(motif_report_t * mr)
{
    return mr->type;
}
