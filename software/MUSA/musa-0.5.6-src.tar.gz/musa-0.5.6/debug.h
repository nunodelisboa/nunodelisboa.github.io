/*

        Headers for debug.c

        by Nuno D. Mendes
	$Id: debug.h,v 1.3 2007/03/02 16:40:25 nnmen Exp $


*/


#ifndef DEBUG_H
#define DEBUG_H

#include <stdarg.h>

void _debug(unsigned int, unsigned int, char *, va_list);
void debug(int, char *, va_list);
void debug_l(int, char *, va_list);
void debug_nl(int);
void error(char *, ...);
void warn(char *, ...);
void message(char *, ...);
void message_l(char *, ...);
void say(char *, ...);
void say_nl();

#endif
